
"""
ALERT TRIGGER (CHANGED 2026-10-19, per request — "alert asbe MACD & RSI
based, 15 minit"): a signal fires for a closed 15-min candle only when

  1. the MACD LINE crosses its SIGNAL LINE on THAT exact candle
     (bullish = crossing up, bearish = crossing down), and
  2. RSI(14) agrees (> config.ALERT_RSI_BULLISH_MIN for bullish,
     < config.ALERT_RSI_BEARISH_MAX for bearish).

That's all. VWAP side, candle volume, last-day volume / delivery vs their
1-month averages, EMA trend and so on are NOT gates anymore (their
REQUIRE_* flags in config.py are False) — they are shown on the alert as
information. (Earlier history: 2026-09-05 the trigger moved from an
EMA9/20 cross to the MACD cross; this change removes the extra gates.)

compute_position_info() below builds the 1st-15-min / 75-min / 1-month
"position" lines shown on the alert.
"""

import datetime as _dt

import math
import pandas as pd

import config
from indicators import (
    add_emas, add_rsi, add_volume_avg, add_ema50, add_macd,
    detect_candle_pattern, add_atr, add_ema,
)

# How close price needs to be to R3/S3 (as a % of price) to be flagged
# as "near" that level, rather than "mid-range".
PIVOT_PROXIMITY_PCT = 0.3


def _min_required_len(lookback, ema_slow=None):
    ema_slow = ema_slow if ema_slow is not None else config.EMA_SLOW
    return max(ema_slow, config.RSI_PERIOD, config.VOLUME_AVG_PERIOD, config.MACD_SLOW, 50) + lookback + 1


def _detect_macd_cross_recent(df, idx, lookback):
    """
    "MACD cross must be within [the lookback]" (added, per request) —
    a genuine MACD LINE crossing its SIGNAL line (sign of
    macd_line - macd_signal flipping) somewhere in the trailing
    `lookback` candles ending at idx. This is DIFFERENT from
    _detect_macd_divergence above (that's price vs MACD divergence,
    unrelated) and different from a plain "macd_line > macd_signal"
    level check (that's just today's current bias regardless of how
    long ago it crossed, or whether it even crossed at all this
    session). Reuses config.MACD_DIVERGENCE_LOOKBACK_CANDLES as the
    window (same "how far back is still recent enough" number already
    used for MACD elsewhere), rather than introducing a second lookback
    constant for a very similar idea.
    Returns "BULLISH" if the LATEST sign-flip in the window was
    macd_line crossing UP through macd_signal, "BEARISH" if the latest
    flip was crossing DOWN, or None if there was no flip in the window
    (or not enough data) -- caller compares this against the signal's
    direction, same pattern as opening_range_breakout.
    """
    window_start = max(0, idx - lookback + 1)
    window = df.iloc[window_start: idx + 1]
    if len(window) < 2 or "macd_line" not in window or "macd_signal" not in window:
        return None
    diff = window["macd_line"] - window["macd_signal"]
    if diff.isna().any():
        return None
    sign = diff.gt(0)
    flips = sign.ne(sign.shift(1))
    flips.iloc[0] = False  # first row has nothing to compare against
    flip_positions = flips[flips].index
    if len(flip_positions) == 0:
        return None
    latest_flip = flip_positions[-1]
    return "BULLISH" if sign.loc[latest_flip] else "BEARISH"


def _detect_macd_divergence(df, idx, lookback):
    """
    Simple half-window divergence check: splits the trailing `lookback`
    candles (ending at idx) into two halves and compares the extreme
    price point in each half against the MACD line at that same index.
      Bullish divergence: price's lowest low in the recent half is LOWER
      than its lowest low in the earlier half, but the MACD line at that
      recent low is HIGHER than the MACD line at the earlier low (price
      falling faster than downside momentum — weakening downtrend).
      Bearish divergence: mirror, using highs and MACD peaks (price
      rising to a new high while MACD makes a lower high — weakening
      uptrend).
    Returns {"bullish": bool, "bearish": bool} — both False if the
    window is too short or no divergence is present.
    """
    window_start = max(0, idx - lookback + 1)
    window = df.iloc[window_start: idx + 1]
    if len(window) < 4:
        return {"bullish": False, "bearish": False}

    mid = len(window) // 2
    first_half = window.iloc[:mid]
    second_half = window.iloc[mid:]

    first_low_pos = first_half["low"].idxmin()
    second_low_pos = second_half["low"].idxmin()
    bullish = (
        df.loc[second_low_pos, "low"] < df.loc[first_low_pos, "low"]
        and df.loc[second_low_pos, "macd_line"] > df.loc[first_low_pos, "macd_line"]
    )

    first_high_pos = first_half["high"].idxmax()
    second_high_pos = second_half["high"].idxmax()
    bearish = (
        df.loc[second_high_pos, "high"] > df.loc[first_high_pos, "high"]
        and df.loc[second_high_pos, "macd_line"] < df.loc[first_high_pos, "macd_line"]
    )

    return {"bullish": bool(bullish), "bearish": bool(bearish)}


def _compute_opening_range_breakout(df, idx):
    """
    Checklist item "1st 15-min High/Low breakout + candle close beyond
    it" (added, per request). Finds TODAY's first candle in df (same
    "first row of today" logic as get_opening_candle_bias, but usable
    at any idx, not just the latest row -- needed here since this runs
    inside _evaluate_candle for whichever candle is being scored) and
    checks whether candle `idx` CLOSED beyond that opening candle's
    high/low:
      - close > opening_high -> "BULLISH" (breakout above the opening
        range, closing outside it -- not just wicking through)
      - close < opening_low  -> "BEARISH" (breakdown below the opening
        range)
      - neither, OR idx IS today's first candle itself (nothing to
        break out of yet) -> None
    df is expected to be 15-min candles (df15) -- same timeframe the
    checklist itself is defined on. Never raises; returns None on any
    missing/insufficient data rather than blocking the caller.
    """
    curr = df.iloc[idx]
    ts = df["timestamp"]
    today = curr["timestamp"].date() if hasattr(curr["timestamp"], "date") else None
    if today is None:
        return None
    today_mask = ts.dt.date == today
    today_positions = [i for i, v in enumerate(today_mask) if v]
    if not today_positions or today_positions[0] == idx:
        return None
    opening_idx = today_positions[0]
    opening_high = float(df.iloc[opening_idx]["high"])
    opening_low = float(df.iloc[opening_idx]["low"])
    close_price = float(curr["close"])
    if close_price > opening_high:
        return "BULLISH"
    if close_price < opening_low:
        return "BEARISH"
    return None


def _compute_vwap_at(df, idx):
    """
    Cumulative session VWAP up to and including candle `idx`:
        VWAP = sum(typical_price * volume) / sum(volume)
    where typical_price = (high + low + close) / 3 for each candle.
    df is assumed to contain only the current trading session's candles
    (true for data from Upstox's intraday endpoint), so no explicit
    "since market open" filtering is needed — row 0 already is the
    session's first candle.
    """
    window = df.iloc[: idx + 1]
    # FIX: df15/df75 now carry MULTI-DAY history (warm-up for MACD/EMA),
    # so a plain cumulative sum was a multi-day VWAP (e.g. AUBANK showed
    # VWAP 1043 vs close 1003 on the 09:15 candle). VWAP must reset each
    # session -> keep only rows dated the same day as candle `idx`.
    if "timestamp" in window.columns and len(window) > 0:
        try:
            day = window["timestamp"].iloc[-1].date()
            window = window[window["timestamp"].dt.date == day]
        except Exception:
            pass  # unusable timestamps -> old whole-df behaviour
    typical_price = (window["high"] + window["low"] + window["close"]) / 3
    cum_vol = window["volume"].sum()
    if cum_vol <= 0:
        return None
    return float((typical_price * window["volume"]).sum() / cum_vol)


def _find_swing_points(df, end_idx, lookback, strength):
    """
    Fractal swing-point finder used by detect_trendline_break().
    Scans df in [end_idx-lookback, end_idx-1] (never includes end_idx
    itself — that's the candle being tested for a break) and returns
    two lists of (idx, price) tuples, oldest first:
      swing_highs: candles whose high is the max of the `strength`
                   candles on BOTH sides of it
      swing_lows:  candles whose low is the min of the `strength`
                   candles on BOTH sides of it
    A candle needs `strength` candles free on both sides to even be
    checked, so the most recent possible swing point is at
    end_idx-1-strength, not end_idx-1.
    """
    start = max(strength, end_idx - lookback)
    stop = end_idx - strength  # exclusive
    swing_highs, swing_lows = [], []
    for p in range(start, stop):
        window_hi = df["high"].iloc[p - strength: p + strength + 1]
        window_lo = df["low"].iloc[p - strength: p + strength + 1]
        if df["high"].iloc[p] == window_hi.max():
            swing_highs.append((p, float(df["high"].iloc[p])))
        if df["low"].iloc[p] == window_lo.min():
            swing_lows.append((p, float(df["low"].iloc[p])))
    return swing_highs, swing_lows


def _trendline_value_at(p1, p2, x):
    """Linear interpolation/extrapolation of the line through p1,p2 at x."""
    (x1, y1), (x2, y2) = p1, p2
    slope = (y2 - y1) / (x2 - x1)
    return y2 + slope * (x - x2)


def detect_trendline_break(df, idx, lookback=None, strength=None):
    """
    Diagonal trendline break (added, per request) — classic "connect
    the last two swing highs/lows and watch for price to close through
    that diagonal line" break, independent of EMA/RSI/VWAP/etc.

    Resistance line: drawn through the last 2 confirmed swing HIGHS,
    only valid if they're descending (2nd high < 1st high — a real
    downtrend line, not a flat/rising one). A BULLISH break fires when
    today's close crosses above that line while the previous candle's
    close was still at/below it (catches the exact breaking candle,
    not every candle after an old break).

    Support line: mirror image — last 2 confirmed swing LOWS, only
    valid if ascending (2nd low > 1st low). A BEARISH break fires when
    close crosses below it, previous candle still at/above it.

    Both lines are checked independently — in principle both a
    resistance and a support line could exist at once (e.g. inside a
    triangle), but only one can actually be broken by a single candle's
    close, so at most one break is ever returned.

    Returns None if no swing pair / no break, else:
      {"direction": "BULLISH" | "BEARISH",
       "line_type": "RESISTANCE" | "SUPPORT",
       "line_value": float (line's value at the break candle),
       "point1": {"idx", "time", "price"},   # older swing point
       "point2": {"idx", "time", "price"},   # newer swing point
       "candles_in_trend": int}              # point2.idx - point1.idx
    """
    lookback = lookback or config.TRENDLINE_LOOKBACK_CANDLES
    strength = strength or config.TRENDLINE_SWING_STRENGTH

    if idx < 1 or idx - lookback < strength + 1:
        return None

    swing_highs, swing_lows = _find_swing_points(df, idx, lookback, strength)

    close_now = float(df["close"].iloc[idx])
    close_prev = float(df["close"].iloc[idx - 1])

    # ---- resistance line (descending swing highs) -> bullish break ----
    if len(swing_highs) >= 2:
        p1, p2 = swing_highs[-2], swing_highs[-1]
        if p2[1] < p1[1]:  # descending
            line_now = _trendline_value_at(p1, p2, idx)
            line_prev = _trendline_value_at(p1, p2, idx - 1)
            if close_now > line_now and close_prev <= line_prev:
                return {
                    "direction": "BULLISH",
                    "line_type": "RESISTANCE",
                    "line_value": round(line_now, 2),
                    "point1": {"idx": p1[0], "time": df["timestamp"].iloc[p1[0]], "price": round(p1[1], 2)},
                    "point2": {"idx": p2[0], "time": df["timestamp"].iloc[p2[0]], "price": round(p2[1], 2)},
                    "candles_in_trend": p2[0] - p1[0],
                }

    # ---- support line (ascending swing lows) -> bearish break ----
    if len(swing_lows) >= 2:
        p1, p2 = swing_lows[-2], swing_lows[-1]
        if p2[1] > p1[1]:  # ascending
            line_now = _trendline_value_at(p1, p2, idx)
            line_prev = _trendline_value_at(p1, p2, idx - 1)
            if close_now < line_now and close_prev >= line_prev:
                return {
                    "direction": "BEARISH",
                    "line_type": "SUPPORT",
                    "line_value": round(line_now, 2),
                    "point1": {"idx": p1[0], "time": df["timestamp"].iloc[p1[0]], "price": round(p1[1], 2)},
                    "point2": {"idx": p2[0], "time": df["timestamp"].iloc[p2[0]], "price": round(p2[1], 2)},
                    "candles_in_trend": p2[0] - p1[0],
                }

    return None


def check_trendline_scan(df, symbol, lookback=None, strength=None):
    """
    Standalone Trendline Break scan entry point (added, per request) —
    separate from check_signals()/EMA cross entirely; a break here
    does NOT require an EMA cross on the same candle. Checks ONLY the
    latest closed candle (unlike check_signals' multi-candle
    CROSS_LOOKBACK_CANDLES catch-up window) since main.py calls this
    every scan cycle on the freshly fetched df, so there's no gap to
    catch up on, and re-scanning old candles every run would just
    re-detect the same already-alerted break.

    Returns a signal dict ready for telegram_notifier.send_trendline_alert,
    or None if nothing broke on the latest candle.
    """
    if len(df) < 5:
        return None
    idx = len(df) - 1
    brk = detect_trendline_break(df, idx, lookback=lookback, strength=strength)
    if brk is None:
        return None

    candle_time = df["timestamp"].iloc[idx]
    return {
        "symbol": symbol,
        "direction": brk["direction"],
        "line_type": brk["line_type"],
        "line_value": brk["line_value"],
        "close": round(float(df["close"].iloc[idx]), 2),
        "candle_time": candle_time,
        "point1": brk["point1"],
        "point2": brk["point2"],
        "candles_in_trend": brk["candles_in_trend"],
    }


def detect_liquidity_sweep(df, idx, swing_lookback=10, prev_day_high=None, prev_day_low=None):
    """
    Liquidity Sweep detector (added, per request, 2026-09-05) — checks
    ONE candle (idx) for a swept-and-reversed level: the candle's
    high/low pierces a level where resting stop-loss/breakout orders
    sit, but the candle CLOSES back on the other side of it — the
    breakout failed and price likely reverses. Two kinds of level are
    checked independently, and BOTH may fire on the same candle:

      - Rolling swing high/low on THIS timeframe: the max high / min
        low of the `swing_lookback` candles immediately BEFORE idx
        (idx itself excluded).
      - Previous day's high/low: fixed levels passed in from
        main.py's build_pivot_levels (fetch_prev_day_ohlc) — None if
        unavailable, in which case that check is simply skipped
        (missing data never fires a false signal).

    Returns a list of 0-2 dicts: {"direction", "levels_swept"} — a
    BEARISH entry if a high was swept, a BULLISH entry if a low was
    swept (both can appear together if this candle swept a high on
    one basis and a low on the other, or the same side on both bases
    collapses into one entry with two level strings).
    """
    if idx < swing_lookback:
        return []
    curr = df.iloc[idx]
    window = df.iloc[idx - swing_lookback: idx]
    if window.empty:
        return []

    swing_high = window["high"].max()
    swing_low = window["low"].min()

    bear_levels = []
    bull_levels = []

    if curr["high"] > swing_high and curr["close"] < swing_high:
        bear_levels.append(f"{swing_lookback}-candle swing high ({round(float(swing_high), 2)})")
    if curr["low"] < swing_low and curr["close"] > swing_low:
        bull_levels.append(f"{swing_lookback}-candle swing low ({round(float(swing_low), 2)})")

    if prev_day_high is not None and prev_day_high > 0:
        if curr["high"] > prev_day_high and curr["close"] < prev_day_high:
            bear_levels.append(f"Previous day high ({round(float(prev_day_high), 2)})")
    if prev_day_low is not None and prev_day_low > 0:
        if curr["low"] < prev_day_low and curr["close"] > prev_day_low:
            bull_levels.append(f"Previous day low ({round(float(prev_day_low), 2)})")

    out = []
    if bear_levels:
        out.append({"direction": "BEARISH", "levels_swept": bear_levels})
    if bull_levels:
        out.append({"direction": "BULLISH", "levels_swept": bull_levels})
    return out


def check_liquidity_sweep_scan(df, symbol, swing_lookback=None, prev_day_high=None, prev_day_low=None):
    """
    Standalone Liquidity Sweep scan entry point (added, per request) —
    completely separate from the MACD-cross alert above (check_signals)
    and from the Trendline Break scan; checks ONLY the latest closed
    candle (same "no catch-up window" reasoning as
    check_trendline_scan — main.py calls this every scan cycle on the
    freshly fetched df, so there's no gap to catch up on).

    Returns a list of 0-2 signal dicts ready for
    telegram_notifier.send_liquidity_sweep_alert.
    """
    if swing_lookback is None:
        swing_lookback = config.LIQUIDITY_SWEEP_SWING_LOOKBACK
    if len(df) < swing_lookback + 2:
        return []

    idx = len(df) - 1
    matches = detect_liquidity_sweep(df, idx, swing_lookback, prev_day_high, prev_day_low)
    if not matches:
        return []

    curr = df.iloc[idx]
    candle_time = df["timestamp"].iloc[idx]
    signals = []
    for m in matches:
        signals.append({
            "symbol": symbol,
            "direction": m["direction"],
            "levels_swept": m["levels_swept"],
            "high": round(float(curr["high"]), 2),
            "low": round(float(curr["low"]), 2),
            "close": round(float(curr["close"]), 2),
            "candle_time": candle_time,
        })
    return signals


def check_ma_envelope(df, symbol, ema200, pct=None):
    """
    Moving Average Envelope touch/break (added, per request, 2026-09-09
    — "Ei strategy develop kore alert hobe?", matching a TradingView
    "Env 200 14 close" indicator: EMA(200) on DAILY closes, with a
    fixed +/-pct% band around it).

    ema200: the daily EMA(200) value, computed elsewhere on daily
    closes (see main.py's _compute_ema50_200_cross, which already
    computes this for the EMA50/200 daily-cross feature — reused here
    rather than recomputed, so no extra API call is needed). None if
    unavailable (not enough daily history yet) — this simply returns
    None, never fires a false signal.

    df: the intraday df already fetched for the main scan (whichever
    timeframe main.py is passing around, e.g. 15-min) — used only to
    read TODAY's session high/low/close so far, not for the EMA math.

    upper = ema200 * (1 + pct/100); lower = ema200 * (1 - pct/100).
    BEARISH: today's high has touched/broken the upper band (price
    stretched into overbought territory relative to the 200-day EMA).
    BULLISH: today's low has touched/broken the lower band (oversold).
    If a huge-range day trips both bands, BEARISH takes priority (the
    rarer, more decisive case) — see the elif below.

    Returns a signal dict or None.
    """
    if pct is None:
        pct = config.MA_ENVELOPE_PCT
    if ema200 is None or ema200 <= 0 or df.empty:
        return None

    today_date = str(df["timestamp"].iloc[-1]).split(" ")[0]
    today_rows = df[df["timestamp"].astype(str).str.startswith(today_date)]
    if today_rows.empty:
        return None

    today_high = float(today_rows["high"].max())
    today_low = float(today_rows["low"].min())
    today_close = float(today_rows["close"].iloc[-1])

    upper = round(ema200 * (1 + pct / 100), 2)
    lower = round(ema200 * (1 - pct / 100), 2)

    if today_high >= upper:
        direction = "BEARISH"
        band = upper
    elif today_low <= lower:
        direction = "BULLISH"
        band = lower
    else:
        return None

    return {
        "symbol": symbol,
        "direction": direction,
        "ema200": round(float(ema200), 2),
        "band": band,
        "pct": pct,
        "high": round(today_high, 2),
        "low": round(today_low, 2),
        "close": round(today_close, 2),
        "candle_time": str(df["timestamp"].iloc[-1]),
    }


def compute_daily_score(curr, prev, vwap, close_price):
    """
    "Daily Score" (added, per request) — a fixed 8-point bullish-quality
    checklist (was 7; MACD added per follow-up request), independent of
    whatever direction the EMA cross itself fired in and independent of
    the scan's own EMA_FAST/EMA_SLOW pair. Unlike a variable-denominator
    score (which would scale /N over only the dimensions that had data),
    every one of these 8 checks always has data by the time
    _evaluate_candle calls this, so it's a plain count out of a fixed
    8 — no scaling.

    The 8 checks:
      1. Close > VWAP
      2. EMA9 > EMA21           (fixed ds_ema9 / ds_ema21 columns)
      3. EMA21 > EMA50          (ds_ema21 vs ema_trend, also fixed)
      4. RSI(14) > 50
      5. RSI(14) < 70
      6. Volume > SMA(Volume, 20) x 1.5   (curr.vol_avg is already
         SMA(Volume, config.VOLUME_AVG_PERIOD=20))
      7. Close > 1 candle ago High (prev.high)
      8. MACD line > MACD signal (curr.macd_line/macd_signal — already
         computed every run via add_macd, same 3-min df, no extra
         fetch). Bullish-crossover framing, same as every other check
         here — not compared against the alert's own direction (that's
         what the intraday checklist's / recent-cross MACD checks are
         for elsewhere).

    Purely informational — never blocks or filters an alert. Any check
    whose input is missing (e.g. VWAP is None on the very first candle
    of a session, or MACD hasn't warmed up yet) simply counts as
    not-met rather than being excluded, so the score is always out of
    a flat 8 and directly comparable across every alert.

    Returns {"score": int (0-8), "total": 8, "checks": dict, "label": str}.
    """
    rsi_val = curr["rsi"] if not pd_isna(curr["rsi"]) else None
    vol_avg = curr["vol_avg"] if not pd_isna(curr["vol_avg"]) else None
    macd_line = curr["macd_line"] if not pd_isna(curr["macd_line"]) else None
    macd_signal = curr["macd_signal"] if not pd_isna(curr["macd_signal"]) else None

    checks = {
        "close_above_vwap":   vwap is not None and close_price > vwap,
        "ema9_above_ema21":   float(curr["ds_ema9"]) > float(curr["ds_ema21"]),
        "ema21_above_ema50":  float(curr["ds_ema21"]) > float(curr["ema_trend"]),
        "rsi_above_50":       rsi_val is not None and rsi_val > 50,
        "rsi_below_70":       rsi_val is not None and rsi_val < 70,
        "volume_spike_1_5x":  vol_avg is not None and vol_avg > 0 and curr["volume"] > (1.5 * vol_avg),
        "close_above_prev_high": close_price > float(prev["high"]),
        "macd_bullish":       macd_line is not None and macd_signal is not None and macd_line > macd_signal,
    }
    score = sum(1 for v in checks.values() if v)
    total = len(checks)

    return {
        "score": score,
        "total": total,
        "checks": checks,
        "label": f"{score}/{total}",
    }


def compute_daily_score_scan(df, symbol):
    """
    Standalone Daily Score check (added, per request — "ami alada ekta
    alert chai sob FNO STOCKER DAILY SCORE... ekta combined report/list
    — sob F&O stock er Daily Score ekshathe ekta message-e, 8/8 hole")
    — computes Daily Score for the LATEST closed candle only,
    completely independent of whether an EMA cross happened on it.
    Used by main.py to build the combined "Perfect Daily Score" F&O
    report (all qualifying stocks listed together in ONE message,
    rather than send_alert's per-symbol EMA-cross alert).

    Reuses the SAME primary_df each symbol's EMA-cross check already
    has in memory this run — no extra fetch. Adds the ds_ema9/ds_ema21/
    ema_trend/rsi/vol_avg columns needed by compute_daily_score if
    they aren't already on df (they usually already are, since
    check_signals/_evaluate_candle computed them moments earlier on
    this same df — the `in df.columns` guards make this a no-op then).

    Returns None if df doesn't have enough history for EMA50 to be
    meaningful yet. Otherwise:
      {"symbol", "score", "total", "label", "close", "candle_time"}
    — same daily_score fields, just flattened with symbol/close/time
    for easy sorting/listing in the report.
    """
    if df is None or len(df) < 55:
        return None

    if "ds_ema9" not in df.columns:
        df = add_ema(df, 9, "ds_ema9")
    if "ds_ema21" not in df.columns:
        df = add_ema(df, 21, "ds_ema21")
    if "ema_trend" not in df.columns:
        df = add_ema50(df)
    if "rsi" not in df.columns:
        df = add_rsi(df, config.RSI_PERIOD)
    if "vol_avg" not in df.columns:
        df = add_volume_avg(df, config.VOLUME_AVG_PERIOD)
    if "macd_line" not in df.columns or "macd_signal" not in df.columns:
        df = add_macd(df, config.MACD_FAST, config.MACD_SLOW, config.MACD_SIGNAL)

    idx = len(df) - 1
    curr = df.iloc[idx]
    prev = df.iloc[idx - 1]
    vwap = _compute_vwap_at(df, idx)
    close_price = float(curr["close"])

    daily_score = compute_daily_score(curr, prev, vwap, close_price)

    # Buy Score (added, per request — "daily score r sathe khali buy
    # score ta o add kore dao") — reuses the same 8-point
    # compute_intraday_checklist strategy.compute_intraday_checklist
    # every EMA-cross alert already shows, direction fixed to BULLISH
    # since Daily Score itself is a bullish-quality-only checklist (see
    # docstring above). Built from a pseudo-signal populated with
    # whatever's cheaply available on this SAME primary_df already in
    # memory (EMA9/21, VWAP, volume vs previous candle, volume vs its
    # average, a recent MACD cross, RSI) -- no extra fetch. The two
    # opening-candle checks (opening_candle_bias / opening_range_
    # breakout) need a separate 15-min fetch that only happens for
    # symbols with an actual EMA-cross signal this run, so they're left
    # out here; compute_intraday_checklist already treats a missing
    # field as "check not satisfied" (0 points), same as a real no, so
    # this just naturally scores out of 10 with those two unavailable.
    vol_change_pct = None
    if prev["volume"]:
        vol_change_pct = (float(curr["volume"]) - float(prev["volume"])) / float(prev["volume"]) * 100

    macd_cross_recent = _detect_macd_cross_recent(df, idx, config.MACD_DIVERGENCE_LOOKBACK_CANDLES)

    buy_signal = {
        "direction": "BULLISH",
        "ema_fast": float(curr["ds_ema9"]),
        "ema_slow": float(curr["ds_ema21"]),
        "close": close_price,
        "vwap": vwap,
        "vol_change_pct": vol_change_pct,
        "volume": float(curr["volume"]),
        "vol_avg": float(curr["vol_avg"]) if pd.notna(curr.get("vol_avg")) else None,
        "macd_cross_recent": macd_cross_recent,
        "rsi": float(curr["rsi"]) if pd.notna(curr.get("rsi")) else None,
    }
    buy_score = compute_intraday_checklist(buy_signal)

    return {
        "symbol": symbol,
        "score": daily_score["score"],
        "total": daily_score["total"],
        "label": daily_score["label"],
        "buy_score": buy_score["score"],
        "buy_score_label": buy_score["label"],
        "close": close_price,
        "candle_time": curr["timestamp"],
    }


def _evaluate_candle(df, idx, symbol, r3, s3, require_trend_confirmation=True, prev_close=None,
                      ema_fast_period=None, ema_slow_period=None, require_volume_increase=False,
                      require_macd_cross=False, require_rsi_confirmation=False,
                      require_vwap_confirmation=False, require_macd_divergence=False):
    ema_fast_period = ema_fast_period if ema_fast_period is not None else config.EMA_FAST
    ema_slow_period = ema_slow_period if ema_slow_period is not None else config.EMA_SLOW

    curr = df.iloc[idx]
    prev = df.iloc[idx - 1]

    # Condition 1 (CHANGED, per request, 2026-09-05 — "Ema cross charo,
    # Macd cross final koro" — EMA9/20 cross removed as the trigger;
    # a signal now fires on a genuine MACD LINE crossing its SIGNAL
    # LINE on THIS candle instead, checked on whichever timeframe is
    # passed in (15-min, since config.PRIMARY_TIMEFRAME="15min"). This
    # is a plain, exact crossover on the current candle — different
    # from _detect_macd_cross_recent below (that scans a trailing
    # window for the MOST RECENT flip, used only for the informational
    # "last cross" timestamp now, not as the trigger) and different
    # from _detect_macd_divergence (price-vs-MACD divergence, a
    # separate condition — see require_macd_divergence further down).
    # EMA9/20 itself is no longer a gating condition at all; its
    # values are still computed/attached to the signal purely as
    # informational context (see "ema_fast"/"ema_slow" in the returned
    # dict, and the trend3_block on the other timeframe).
    prev_macd_diff = prev["macd_line"] - prev["macd_signal"]
    curr_macd_diff = curr["macd_line"] - curr["macd_signal"]
    bullish_cross = prev_macd_diff <= 0 and curr_macd_diff > 0
    bearish_cross = prev_macd_diff >= 0 and curr_macd_diff < 0

    if not (bullish_cross or bearish_cross):
        return None

    direction = "BULLISH" if bullish_cross else "BEARISH"
    bullish = bullish_cross
    close_price = float(curr["close"])

    # Condition 2: cross direction must agree with the broader trend
    # (EMA50) — a bullish cross only fires in an uptrend, a bearish
    # cross only fires in a downtrend. This is MANDATORY for stocks and
    # commodities, but SKIPPED for indices (require_trend_confirmation
    # =False) — for indices we want every qualifying crossover alerted
    # regardless of the EMA50 trend. stock_trend is still computed and
    # shown in the message either way, purely informational when the
    # condition isn't enforced.
    stock_trend = "BULLISH" if curr["close"] > curr["ema_trend"] else "BEARISH"
    if require_trend_confirmation and direction != stock_trend:
        return None

    # Volume — MANDATORY when require_volume_increase=True (currently
    # only the 75-min stock/F&O/cash/commodity alerts — see
    # check_signals/main.py): the crossing candle's volume must be
    # strictly higher than the previous candle's, or the signal is
    # rejected outright. If prev_vol is 0/unavailable, the comparison
    # can't be made — the alert still fires rather than being blocked
    # on missing data, same as before. When require_volume_increase is
    # False (indices, and everywhere else by default), volume stays
    # informational-only, exactly as before.
    curr_vol = curr["volume"]
    prev_vol = prev["volume"]
    vol_change_pct = round(((curr_vol - prev_vol) / prev_vol) * 100, 1) if prev_vol else None
    if require_volume_increase and prev_vol and curr_vol <= prev_vol:
        return None
    rsi_val = curr["rsi"] if not pd_isna(curr["rsi"]) else None

    # RSI condition — MANDATORY when require_rsi_confirmation=True
    # (added, per request): RSI(14) above ALERT_RSI_BULLISH_MIN for a
    # BULLISH cross, below ALERT_RSI_BEARISH_MAX for a BEARISH cross,
    # or the signal is rejected outright. If rsi_val
    # is unavailable (not enough history yet), the alert still fires
    # rather than being blocked on missing data — same
    # missing-data-never-blocks philosophy as require_volume_increase
    # above.
    if require_rsi_confirmation and rsi_val is not None:
        # Thresholds are config.ALERT_RSI_BULLISH_MIN / _BEARISH_MAX
        # (both 50 by default) — editable without touching this file.
        if bullish and rsi_val <= config.ALERT_RSI_BULLISH_MIN:
            return None
        if not bullish and rsi_val >= config.ALERT_RSI_BEARISH_MAX:
            return None

    cross_pattern = detect_candle_pattern(curr)
    prev_pattern = detect_candle_pattern(prev)

    # Informational trade-plan fields — never affect whether a signal
    # fires. Stop Loss = EMA20 on the cross candle. Target = the
    # trailing 15-min (config.TARGET_LOOKBACK_CANDLES candles) high for
    # a bullish entry, or the trailing 15-min low for a bearish entry.
    window_start = max(0, idx - (config.TARGET_LOOKBACK_CANDLES - 1))
    window = df.iloc[window_start:idx + 1]
    if bullish:
        target = float(window["high"].max())
    else:
        target = float(window["low"].min())
    stop_loss = float(curr["ema_slow"])

    # Risk:Reward, expressed as reward per 1 unit of risk (e.g. 2.35
    # means "1 : 2.35"). None if risk is 0 (entry == stop loss), which
    # can happen right at the cross when EMA20 == close.
    risk = abs(close_price - stop_loss)
    reward = abs(target - close_price)
    risk_reward = round(reward / risk, 2) if risk > 0 else None

    pivot_note = None
    if r3 is not None and s3 is not None:
        if close_price >= r3:
            pivot_note = f"Above R3 ({r3}) — resistance broken"
        elif close_price <= s3:
            pivot_note = f"Below S3 ({s3}) — support broken"
        else:
            dist_to_r3_pct = abs(r3 - close_price) / close_price * 100
            dist_to_s3_pct = abs(close_price - s3) / close_price * 100
            if dist_to_r3_pct <= PIVOT_PROXIMITY_PCT:
                pivot_note = f"Near R3 ({r3}), {dist_to_r3_pct:.2f}% away — near resistance"
            elif dist_to_s3_pct <= PIVOT_PROXIMITY_PCT:
                pivot_note = f"Near S3 ({s3}), {dist_to_s3_pct:.2f}% away — near support"
            else:
                pivot_note = "Mid-range (not near R3/S3)"

    # VWAP — purely informational. Flags whether price is trading above
    # or below the session VWAP at the moment of the cross, and by what
    # %. None if volume data is unusable (cum_vol == 0), in which case
    # the alert simply omits the VWAP line.
    vwap = _compute_vwap_at(df, idx)
    vwap_note = None
    if vwap is not None and vwap > 0:
        vwap_diff_pct = round((close_price - vwap) / vwap * 100, 2)
        position = "Above VWAP" if close_price >= vwap else "Below VWAP"
        vwap_note = f"{position} ({vwap_diff_pct:+.2f}%)"

    # VWAP direction condition — MANDATORY when require_vwap_confirmation
    # =True (added, per request): close must sit on the side of VWAP
    # that agrees with the cross direction — at/above VWAP for a
    # BULLISH cross, at/below VWAP for a BEARISH cross — or the signal
    # is rejected outright. Missing/unusable VWAP (vwap is None/0)
    # never blocks — same missing-data-never-blocks rule used
    # elsewhere (RSI, volume).
    if require_vwap_confirmation and vwap is not None and vwap > 0:
        if bullish and close_price < vwap:
            return None
        if not bullish and close_price > vwap:
            return None

    # MACD — informational only. macd_line/signal/hist are shown as raw
    # values; macd_divergence flags a bullish/bearish divergence within
    # the trailing config.MACD_DIVERGENCE_LOOKBACK_CANDLES window, if
    # any (see _detect_macd_divergence). Never blocks a signal.
    macd_div = _detect_macd_divergence(df, idx, config.MACD_DIVERGENCE_LOOKBACK_CANDLES)
    macd_divergence_note = None
    if macd_div["bullish"]:
        macd_divergence_note = "Bullish Divergence (price lower low, MACD higher low)"
    elif macd_div["bearish"]:
        macd_divergence_note = "Bearish Divergence (price higher high, MACD lower high)"

    # MACD divergence condition — MANDATORY when require_macd_divergence
    # =True (added, per request): a bullish price/MACD divergence must
    # be present for a BULLISH cross, a bearish divergence for a
    # BEARISH cross, or the signal is rejected outright. This is
    # DIFFERENT from require_macd_cross below (that's a genuine
    # MACD-line/signal-line crossover; this is price-vs-MACD
    # divergence — see _detect_macd_divergence).
    if require_macd_divergence:
        if bullish and not macd_div["bullish"]:
            return None
        if not bullish and not macd_div["bearish"]:
            return None

    # MACD cross recency (added, per request) — used to REQUIRE the
    # MACD condition (Trade Score dimension #11 and the checklist's
    # "MACD bullish/bearish" item) to be a genuinely recent crossover,
    # not just today's current level. See _detect_macd_cross_recent.
    macd_cross_recent = _detect_macd_cross_recent(df, idx, config.MACD_DIVERGENCE_LOOKBACK_CANDLES)

    # MACD condition — MANDATORY when require_macd_cross=True (added,
    # per request): the LATEST MACD line/signal crossover within the
    # lookback window must match this candle's direction (macd_cross_
    # recent == direction), or the signal is rejected outright. UNLIKE
    # require_rsi_confirmation/require_volume_increase above, a None
    # here (no recent MACD crossover at all in the window) DOES block
    # when this is required -- "no recent cross" genuinely fails a
    # "must have a recent cross" requirement, it isn't missing/
    # unusable data the way an unavailable RSI reading is.
    if require_macd_cross and macd_cross_recent != direction:
        return None


    # Day change % — purely informational, vs previous trading day's
    # close (same prev-day close already fetched for R3/S3). None if
    # prev_close wasn't available (e.g. pivot fetch failed for this
    # symbol that day) — the alert simply omits this line then.
    day_change_pct = None
    if prev_close:
        day_change_pct = round((close_price - prev_close) / prev_close * 100, 2)

    # Opening range breakout (added, per request) — checklist item
    # "1st 15-min High/Low breakout + close beyond it". Purely
    # informational here, like trendline_break below; never blocks the
    # EMA-cross signal itself.
    opening_range_breakout = _compute_opening_range_breakout(df, idx)

    daily_score = compute_daily_score(curr, prev, vwap, close_price)

    # Trendline break (added, per request) — informational only here;
    # this is the SAME detect_trendline_break used by the standalone
    # check_trendline_scan, just also surfaced as an extra line when it
    # happens to coincide with this EMA-cross candle. Does not require
    # a break to have happened for the EMA-cross alert itself to fire.
    trendline_break = detect_trendline_break(df, idx)

    return {
        "symbol": symbol,
        "direction": direction,
        "close": round(close_price, 2),
        "entry": round(close_price, 2),
        "stop_loss": round(stop_loss, 2),
        "target": round(target, 2),
        "risk_reward": risk_reward,
        "rsi": round(float(rsi_val), 1) if rsi_val is not None else None,
        "volume": int(curr["volume"]),
        "vol_avg": round(float(curr["vol_avg"]), 0) if not pd_isna(curr["vol_avg"]) else None,
        "vol_change_pct": vol_change_pct,
        "ema_fast": round(float(curr["ema_fast"]), 2),
        "ema_slow": round(float(curr["ema_slow"]), 2),
        "ema_fast_period": ema_fast_period,
        "ema_slow_period": ema_slow_period,
        "ema_trend": round(float(curr["ema_trend"]), 2),
        "stock_trend": stock_trend,
        "candle_time": str(curr.get("timestamp", "")),
        "cross_candle_pattern": cross_pattern,
        "prev_candle_pattern": prev_pattern,
        "r3": r3,
        "s3": s3,
        "pivot_note": pivot_note,
        "prev_close": round(float(prev_close), 2) if prev_close else None,
        "day_change_pct": day_change_pct,
        "vwap": round(vwap, 2) if vwap is not None else None,
        "vwap_note": vwap_note,
        "macd_line": round(float(curr["macd_line"]), 2),
        "macd_signal": round(float(curr["macd_signal"]), 2),
        "macd_hist": round(float(curr["macd_hist"]), 2),
        "macd_divergence": macd_divergence_note,
        "macd_cross_recent": macd_cross_recent,
        "daily_score": daily_score,
        "trendline_break": trendline_break,
        "opening_range_breakout": opening_range_breakout,
    }


def check_signals(df, symbol, r3=None, s3=None, lookback=None, require_trend_confirmation=True, prev_close=None,
                   ema_fast=None, ema_slow=None, require_volume_increase=False, require_strong_candle=False,
                   require_macd_cross=False, require_rsi_confirmation=False,
                   require_vwap_confirmation=False, require_macd_divergence=False, today=None):
    """
    Scans the last `lookback` closed candles (default:
    config.CROSS_LOOKBACK_CANDLES) for a genuine MACD line/signal-line
    crossover on that exact candle (CHANGED, 2026-09-05 — the trigger
    is no longer an EMA9/20 crossover, see _evaluate_candle) — not just
    the single latest candle — so a run that was skipped/delayed still
    catches up on any cross it would otherwise have missed.

    ema_fast/ema_slow: no longer used for the trigger itself (that's
    MACD-based now); kept only to label the informational EMA9/EMA20
    values attached to each signal (defaults to config.EMA_FAST/
    EMA_SLOW, i.e. 9/20 — the F&O scan's periods; pass
    config.NIFTY500_EMA_FAST/EMA_SLOW, 9/21, for the Nifty 500
    cash-stock scan).

    require_trend_confirmation=False disables the EMA50 trend-
    agreement check — informational-only by default now
    (config.REQUIRE_TREND_CONFIRMATION), for every scan.

    require_volume_increase=True makes the crossing candle's volume >
    previous candle's volume a MANDATORY condition (signal rejected
    otherwise).

    require_strong_candle: accepted for call-site compatibility with
    main.py (config.REQUIRE_STRONG_CANDLE), but currently a no-op —
    the strong-candle-body filter was removed from _evaluate_candle
    (see this module's docstring: "There is no longer a strong-candle
    filter"). Kept as a parameter rather than removed so main.py can
    keep passing it without a signature error; has no effect either
    way right now.

    require_macd_cross=True makes a RECENT MACD line/signal crossover
    ALSO required within a trailing lookback window matching this
    candle's direction (see _detect_macd_cross_recent) — this is now
    largely redundant with the exact-candle trigger above and is OFF
    by default; kept available in case a wider "recent cross" window
    (rather than the exact candle) is ever wanted again.

    require_macd_divergence=True (added, per request) makes a
    price-vs-MACD divergence in the matching direction MANDATORY —
    see _detect_macd_divergence. A SEPARATE MACD-based condition from
    the cross trigger above (cross = momentum direction changed right
    now; divergence = price/momentum disagreement building up).

    require_vwap_confirmation=True (added, per request) makes close
    trading on the side of VWAP that matches the direction MANDATORY.

    require_rsi_confirmation=True (added, per request) makes RSI(14)
    > 50 (bullish) / < 50 (bearish) MANDATORY.

    Returns a list of signal dicts, oldest candle first. Empty list if
    nothing qualifies. Caller is responsible for de-duping against
    already-alerted (symbol, direction, candle_time) combos (see
    state.py) before sending each one.
    """
    lookback = lookback or config.CROSS_LOOKBACK_CANDLES
    ema_fast = ema_fast if ema_fast is not None else config.EMA_FAST
    ema_slow = ema_slow if ema_slow is not None else config.EMA_SLOW

    if len(df) < _min_required_len(1, ema_slow):
        return []

    # Shrink the lookback window if we don't have enough history yet
    # (e.g. right after market open) rather than returning nothing.
    max_possible_lookback = len(df) - _min_required_len(0, ema_slow)
    lookback = max(1, min(lookback, max_possible_lookback))

    df = add_emas(df, ema_fast, ema_slow)
    df = add_rsi(df, config.RSI_PERIOD)
    df = add_volume_avg(df, config.VOLUME_AVG_PERIOD)
    df = add_ema50(df)
    df = add_macd(df, config.MACD_FAST, config.MACD_SLOW, config.MACD_SIGNAL)
    # Fixed EMA9/EMA21 for the Daily Score (see compute_daily_score) —
    # kept separate from ema_fast/ema_slow above because those vary by
    # scan (9/20 on F&O, 9/50 on Nifty 500), while the Daily Score's
    # own EMA9 > EMA21 > EMA50 stack must always stay 9/21/50.
    df = add_ema(df, 9, "ds_ema9")
    df = add_ema(df, 21, "ds_ema21")

    signals = []
    n = len(df)
    start = max(1, n - lookback)
    last_macd_diff = float(df["macd_line"].iloc[-1] - df["macd_signal"].iloc[-1])
    for idx in range(start, n):
        # FIX 2026-10-21 (JAINREC alert at 09:38 for a 19-Oct 14:30 candle): the
        # catch-up window must never reach back into an earlier trading day —
        # a 2-day-old cross is not an alert.
        if today is not None and df["timestamp"].iloc[idx].date() != today:
            continue
        sig = _evaluate_candle(
            df, idx, symbol, r3, s3,
            require_trend_confirmation=require_trend_confirmation,
            prev_close=prev_close,
            ema_fast_period=ema_fast,
            ema_slow_period=ema_slow,
            require_volume_increase=require_volume_increase,
            require_macd_cross=require_macd_cross,
            require_rsi_confirmation=require_rsi_confirmation,
            require_vwap_confirmation=require_vwap_confirmation,
            require_macd_divergence=require_macd_divergence,
        )
        if sig is not None:
            # Catch-up crosses (not the latest candle) are dropped if the MACD has
            # already flipped back since — the cross no longer exists.
            if getattr(config, "ALERT_REQUIRE_STILL_VALID", True) and idx < n - 1:
                if sig["direction"] == "BULLISH" and last_macd_diff <= 0:
                    continue
                if sig["direction"] == "BEARISH" and last_macd_diff >= 0:
                    continue
            signals.append(sig)
    return signals


def compute_alert_strength(signal):
    """
    How strongly the MACD+RSI cross is confirmed (ADDED 2026-10-21,
    weighted 2026-10-21 — "MACD cross ke 3 point dao"). Each check is
    direction-aware and SKIPPED when its data is missing, so the ratio is
    points-passed / points-of-checks-that-could-be-made. Weights come from
    config.ALERT_STRENGTH_WEIGHTS (MACD zero-line check = 3 points, rest 1).
    Returns {"passed", "total", "ratio", "label", "checks": [(name, ok, weight)]}
    — passed/total are POINTS.
    """
    bull = signal.get("direction") == "BULLISH"
    pos = signal.get("positions") or {}
    W = getattr(config, "ALERT_STRENGTH_WEIGHTS", {})
    checks = []
    mandatory = set(getattr(config, "ALERT_MANDATORY_CHECKS", ()))
    mandatory_failed = []
    keys = []

    def add(key, name, ok):
        keys.append(key)
        checks.append((name, bool(ok), int(W.get(key, 1))))
        if key in mandatory and not ok:
            mandatory_failed.append(name)

    # volume first (2026-10-22 — "volume sobar opre")
    pdv, avg_v = signal.get("prev_day_volume"), signal.get("volume_avg_1m")
    if pdv is not None and avg_v:
        add("volume", "Last-day volume > 20D avg", pdv > avg_v)

    ml = signal.get("macd_line")
    if ml is not None:
        add("macd_zero", "MACD " + ("above" if bull else "below") + " zero line", ml > 0 if bull else ml < 0)

    rsi = signal.get("rsi")
    if rsi is not None:
        lim = config.ALERT_STRONG_RSI_BULLISH if bull else config.ALERT_STRONG_RSI_BEARISH
        add("rsi", f"RSI {'≥' if bull else '≤'} {lim}", rsi >= lim if bull else rsi <= lim)

    e75 = pos.get("ema75")
    if e75:
        add("ema75", "75-min EMA50 " + ("above" if bull else "below"), (e75["state"] == "ABOVE") == bull)

    note = signal.get("vwap_note") or ""
    if note:
        add("vwap", "VWAP " + ("above" if bull else "below"), note.startswith("Above") == bull)

    f15 = pos.get("first15")
    if f15 and f15.get("state") in ("ABOVE", "BELOW", "INSIDE"):
        add("first15", "1st 15-min " + ("above high" if bull else "below low"), f15["state"] == ("ABOVE" if bull else "BELOW"))

    dp, avg_d = signal.get("delivery_pct"), signal.get("delivery_avg_1m")
    if dp is not None and avg_d:
        add("delivery", "Last-day delivery > 20D avg", dp > avg_d)

    vc = signal.get("vol_change_pct")
    if vc is not None:
        add("candle_volume", "Candle volume up vs previous", vc > 0)

    e15 = signal.get("ema920_15")
    if e15 and e15.get("bias"):
        add("ema920", "EMA 9/20 (15-min) " + ("bullish" if bull else "bearish"), (e15["bias"] == "BULLISH") == bull)

    others = [(n, ok, w) for (n, ok, w), k in zip(checks, keys) if k not in mandatory]
    others_total = sum(w for _, _, w in others)
    others_passed = sum(w for _, ok, w in others if ok)
    others_ratio = others_passed / others_total if others_total else 1.0
    total = sum(w for _, _, w in checks)
    passed = sum(w for _, ok, w in checks if ok)
    ratio = passed / total if total else 1.0
    label = "STRONG" if ratio >= 0.75 else ("MEDIUM" if ratio >= 0.5 else "WEAK")
    # Alert rule (2026-10-22): at least ALERT_MIN_CHECKS_PASSED of the
    # ALERT_FULL_CHECK_COUNT checks. When some data is missing (index/commodity
    # have no delivery/volume avg) the bar is scaled down in proportion.
    full = max(1, int(getattr(config, "ALERT_FULL_CHECK_COUNT", 9)))
    need = math.ceil(getattr(config, "ALERT_MIN_CHECKS_PASSED", 7) * total / full - 1e-9) if total else 0
    meets_min = passed >= need
    return {"passed": passed, "need": need, "meets_min": meets_min, "total": total, "ratio": round(ratio, 2), "label": label,
            "checks": checks, "mandatory_failed": mandatory_failed,
            "others_passed": others_passed, "others_total": others_total,
            "others_ratio": round(others_ratio, 2)}


def check_signal(df, symbol, r3=None, s3=None):
    """
    Backward-compatible single-signal wrapper: returns only the most
    recent qualifying signal (or None), same as the original behavior.
    Prefer check_signals() in new code so missed/delayed runs still
    catch up on earlier crosses in the lookback window.
    """
    signals = check_signals(df, symbol, r3=r3, s3=s3, lookback=1)
    return signals[-1] if signals else None


def debug_ema_gap(df, symbol, ema_fast=None, ema_slow=None):
    """
    Debug helper only — NOT used in the firing decision. Returns how far
    apart EMA9/EMA20 are on the latest closed candle, as a % of price, so
    you can see in the Action logs which instruments are "close" to a
    cross even when none has fired yet.
    """
    ema_fast_period = ema_fast if ema_fast is not None else config.EMA_FAST
    ema_slow_period = ema_slow if ema_slow is not None else config.EMA_SLOW

    if len(df) < ema_slow_period + 2:
        return None

    df = add_emas(df, ema_fast_period, ema_slow_period)
    curr = df.iloc[-1]

    ema_fast_val = float(curr["ema_fast"])
    ema_slow_val = float(curr["ema_slow"])
    close_price = float(curr["close"])
    gap_pct = abs(ema_fast_val - ema_slow_val) / close_price * 100

    return {
        "symbol": symbol,
        "ema_fast": round(ema_fast_val, 2),
        "ema_slow": round(ema_slow_val, 2),
        "gap_pct": round(gap_pct, 3),
        "leaning": f"BULLISH (EMA{ema_fast_period} above)" if ema_fast_val > ema_slow_val else f"BEARISH (EMA{ema_fast_period} below)",
    }


def get_3min_trend_info(df_3min, symbol, lookback_candles=None, ema_fast=None, ema_slow=None):
    """
    Informative-only check on 3-min candles — no filters (no strong
    candle, no volume, no trend-agreement, no gap threshold). Reports:
      - bias: which side EMA9 is currently on relative to EMA20
      - candles_since_cross: how many 3-min candles ago EMA9/20 last
        crossed, within lookback_candles (None = no cross in that
        window — i.e. the 3-min chart has NOT crossed recently)
      - gap_pct: how close EMA9/EMA20 currently are to crossing, as a
        % of close price (0 = touching/about to cross; bigger = further
        from a cross)
    Attached as context to a 75-min alert (the PRIMARY/ALERTING
    timeframe — see check_signals above). Never blocks or fires its own
    alert.

    Returns None if there isn't enough 3-min history yet.
    """
    ema_fast_period = ema_fast if ema_fast is not None else config.EMA_FAST
    ema_slow_period = ema_slow if ema_slow is not None else config.EMA_SLOW

    if len(df_3min) < ema_slow_period + 2:
        return None

    lookback_candles = lookback_candles or config.INFO_3MIN_LOOKBACK_CANDLES

    df = add_emas(df_3min, ema_fast_period, ema_slow_period)
    n = len(df)

    curr = df.iloc[-1]
    bias = "BULLISH" if curr["ema_fast"] > curr["ema_slow"] else "BEARISH"
    close_price = float(curr["close"])
    gap_pct = round(abs(float(curr["ema_fast"]) - float(curr["ema_slow"])) / close_price * 100, 3) if close_price else None

    candles_since_cross = None
    cross_time = None
    start = max(1, n - lookback_candles)
    for idx in range(n - 1, start - 1, -1):
        prev = df.iloc[idx - 1]
        cur = df.iloc[idx]
        bull_cross = prev["ema_fast"] <= prev["ema_slow"] and cur["ema_fast"] > cur["ema_slow"]
        bear_cross = prev["ema_fast"] >= prev["ema_slow"] and cur["ema_fast"] < cur["ema_slow"]
        if bull_cross or bear_cross:
            candles_since_cross = (n - 1) - idx
            # FIXED: this used to read df.index[idx], but after
            # resample_*min() the dataframe index is just a plain
            # 0..n row counter (reset_index()) -- the real timestamp
            # lives in the "timestamp" COLUMN. df.index[idx] was
            # silently returning an integer row number instead of a
            # real date/time, which then crashed inside
            # telegram_notifier.py's date-formatting (str(3).split(" ")
            # has no [1] element -> IndexError) -- silently swallowed
            # by the try/except around send_alert in main.py, so the
            # WHOLE alert would just quietly fail to send whenever this
            # 15-min context block had a recent cross. Reading
            # df.iloc[idx]["timestamp"] instead fixes both the display
            # and this silent-drop bug.
            cross_time = cur["timestamp"]
            break

    return {
        "symbol": symbol,
        "bias": bias,
        "ema_fast": round(float(curr["ema_fast"]), 2),
        "ema_slow": round(float(curr["ema_slow"]), 2),
        "ema_fast_period": ema_fast_period,
        "ema_slow_period": ema_slow_period,
        "gap_pct": gap_pct,  # how close to a cross right now, on 75-min
        "candles_since_cross": candles_since_cross,  # None = no cross in lookback window
        "cross_time": cross_time,  # exact 75-min candle timestamp of the cross, or None
    }


def get_opening_candle_bias(df, symbol):
    """
    Opening 15-min candle bias (added, per request). Looks at the
    FIRST 15-min candle of TODAY's session (the 09:15 candle) in df
    (expects df15 — the 15-min resampled data). Compares that candle's
    open/low/high with a small tolerance (config.OPENING_CANDLE_EPSILON,
    default 0.01) instead of exact float equality, since real market
    data can carry tiny floating-point noise even on a genuinely equal
    tick:
      - Open == Low  -> "BULLISH" (price never traded below the open
        all through the first 15 minutes — no selling below open)
      - Open == High -> "BEARISH" (price never traded above the open
        — no buying above open)
      - Neither (the normal case — price moved both above and below
        open in the first 15 min) -> None, caller omits the line
    Returns None if config.OPENING_CANDLE_BIAS_ENABLED is False, if df
    is empty, or if today's first 15-min candle isn't in df yet (e.g.
    called before/right at market open before that first candle has
    actually closed).
    """
    if not config.OPENING_CANDLE_BIAS_ENABLED:
        return None
    if df is None or df.empty:
        return None
    ts = df["timestamp"]
    today = ts.iloc[-1].date()
    today_rows = df[ts.dt.date == today]
    if today_rows.empty:
        return None
    first = today_rows.iloc[0]
    o = float(first["open"])
    h = float(first["high"])
    l = float(first["low"])
    eps = config.OPENING_CANDLE_EPSILON
    open_eq_low = abs(o - l) <= eps
    open_eq_high = abs(o - h) <= eps
    if open_eq_low and not open_eq_high:
        return "BULLISH"
    if open_eq_high and not open_eq_low:
        return "BEARISH"
    return None


def get_opening_candle_buy_sell_estimate(df, symbol):
    """
    1st 15-min candle Buy/Sell volume ESTIMATE (added, per request).
    NOT real order-flow/tick data (Upstox's historical candle API
    doesn't expose who initiated each trade) -- this is the standard
    Chaikin-style approximation from the candle's own OHLC + volume:

        buy_volume  = volume * (close - low) / (high - low)
        sell_volume = volume - buy_volume

    i.e. a close near the candle's HIGH is read as mostly buy-side
    pressure, a close near the LOW as mostly sell-side. Same
    "today's first 15-min candle" lookup as get_opening_candle_bias
    above (expects df15). Returns None if df is empty, today's first
    candle isn't in df yet, or the candle has zero range (high==low,
    e.g. a single-tick/illiquid candle) -- division by zero would
    otherwise make the split meaningless. On success returns a dict:
    {"buy_volume": int, "sell_volume": int, "buy_pct": float} (buy_pct
    rounded to 1 decimal, 0-100).
    """
    if df is None or df.empty:
        return None
    ts = df["timestamp"]
    today = ts.iloc[-1].date()
    today_rows = df[ts.dt.date == today]
    if today_rows.empty:
        return None
    first = today_rows.iloc[0]
    o, h, l, c = float(first["open"]), float(first["high"]), float(first["low"]), float(first["close"])
    volume = float(first["volume"])
    candle_range = h - l
    if candle_range <= 0 or volume <= 0:
        return None
    buy_volume = volume * (c - l) / candle_range
    sell_volume = volume - buy_volume
    return {
        "buy_volume": int(round(buy_volume)),
        "sell_volume": int(round(sell_volume)),
        "buy_pct": round((buy_volume / volume) * 100, 1),
    }


def _range_position(close, high, low):
    """Where `close` sits relative to a high/low range. Returns None if
    the range is unusable. state: ABOVE (closed over the high), BELOW
    (closed under the low) or INSIDE; pct = position within the range
    (0 = at the low, 100 = at the high; can be <0 / >100 outside it);
    dist_pct = how far outside the range, as % (ABOVE/BELOW only)."""
    if close is None or high is None or low is None or high <= low:
        return None
    pct = (close - low) / (high - low) * 100.0
    dist = None
    if close > high:
        state, dist = "ABOVE", (close - high) / high * 100.0
    elif close < low:
        state, dist = "BELOW", (low - close) / low * 100.0
    else:
        state = "INSIDE"
    return {
        "state": state,
        "high": round(float(high), 2),
        "low": round(float(low), 2),
        "pct": round(pct, 0),
        "dist_pct": round(dist, 2) if dist is not None else None,
    }


def compute_position_info(df15, df75, signal, mv=None):
    """
    "Position" lines for the alert (ADDED 2026-10-19, per request —
    "1st 15 minit position / 75 minit position / one month position").
    Each one answers: where is the alert candle's CLOSE relative to a
    reference high/low range?

      first15 — the day's 1st 15-min candle (09:15-09:30) high/low.
                state SELF if the alert candle IS that candle.
      first75 — the PREVIOUS closed 75-min bar's high/low (default; set
                config.POSITION_75MIN_REFERENCE = "first" for the day's
                1st 75-min bar instead). Carries the 75-min EMA bias
                too (signal["trend_3min"], when it is the 75-min
                context block).
      month   — the last 21 completed trading days' high/low (mv from
                main.build_momentum_volume_data: month_high/month_low).

    "Day" is the ALERT CANDLE's own day, so a catch-up alert for a candle
    from earlier in the session still measures against that day's
    opening candles. Any part with missing data is simply None (the
    message leaves that line out) — this never raises or blocks an alert.
    """
    out = {"first15": None, "first75": None, "month": None, "ema75": None}
    try:
        close = float(signal["close"])
        sig_ts = pd.Timestamp(signal["candle_time"])
        day = sig_ts.date()

        # ---- 1st 15-min candle ----
        if df15 is not None and not df15.empty:
            rows = df15[df15["timestamp"].dt.date == day]
            if not rows.empty:
                first = rows.iloc[0]
                hi, lo = float(first["high"]), float(first["low"])
                if sig_ts <= first["timestamp"]:
                    out["first15"] = {"state": "SELF", "high": round(hi, 2), "low": round(lo, 2)}
                else:
                    out["first15"] = _range_position(close, hi, lo)
                if out["first15"] is not None:
                    out["first15"]["bias"] = signal.get("opening_candle_bias")

        # ---- 75-min ----
        # config.POSITION_75MIN_REFERENCE:
        #   "previous" (default, per request 2026-10-19 — "75 minit to
        #     age theke calculation hobe"): the last fully-closed 75-min
        #     bar BEFORE the 75-min bar the alert candle sits in. At the
        #     open that is yesterday's last bar, so the line is available
        #     from the very first alert of the day.
        #   "first": the day's 1st 75-min bar (09:15-10:30) — shows
        #     "forming" until 10:30.
        ema_tag = None
        t3 = signal.get("trend_3min")
        if t3 and signal.get("info_timeframe_label") == "75-min":
            ema_tag = {
                "bias": t3.get("bias"),
                "fast": t3.get("ema_fast_period"),
                "slow": t3.get("ema_slow_period"),
            }
        if df75 is not None and not df75.empty:
            ref_mode = getattr(config, "POSITION_75MIN_REFERENCE", "previous")
            if ref_mode == "first":
                rows75 = df75[df75["timestamp"].dt.date == day]
                if rows75.empty:
                    out["first75"] = {"state": "FORMING"}
                else:
                    first75 = rows75.iloc[0]
                    hi, lo = float(first75["high"]), float(first75["low"])
                    first75_end = first75["timestamp"] + pd.Timedelta(minutes=75)
                    if sig_ts < first75_end:
                        out["first75"] = {"state": "SELF", "high": round(hi, 2), "low": round(lo, 2)}
                    else:
                        out["first75"] = _range_position(close, hi, lo)
            else:
                # start of the 75-min bar containing the alert candle
                # (bars are aligned to the 09:15 session start, per day)
                day_start = pd.Timestamp(sig_ts.date()).tz_localize(sig_ts.tzinfo) + pd.Timedelta(hours=9, minutes=15) \
                    if sig_ts.tzinfo is not None else pd.Timestamp(sig_ts.date()) + pd.Timedelta(hours=9, minutes=15)
                n_bars = int((sig_ts - day_start) / pd.Timedelta(minutes=75)) if sig_ts >= day_start else 0
                cur_bar_start = day_start + pd.Timedelta(minutes=75 * n_bars)
                prev_rows = df75[df75["timestamp"] < cur_bar_start]
                if not prev_rows.empty:
                    prev_bar = prev_rows.iloc[-1]
                    out["first75"] = _range_position(close, float(prev_bar["high"]), float(prev_bar["low"]))
                    if out["first75"] is not None:
                        out["first75"]["bar_start"] = str(prev_bar["timestamp"])
            if out["first75"] is not None and ema_tag:
                out["first75"]["ema"] = ema_tag

        # ---- 75-min EMA50: is price above it? (informational only) ----
        # Uses the last 75-min bar that was already CLOSED when the alert
        # candle closed (bar_start + 75min <= alert candle end), so a
        # catch-up alert never peeks at a later bar.
        try:
            p = int(getattr(config, "POSITION_75MIN_EMA_PERIOD", 50))
            min_bars = int(getattr(config, "POSITION_75MIN_EMA_MIN_BARS", 60))
            if df75 is not None and len(df75) >= min_bars:
                ema_col = df75["close"].ewm(span=p, adjust=False).mean()
                candle_end = sig_ts + pd.Timedelta(minutes=15)
                closed = df75["timestamp"] + pd.Timedelta(minutes=75) <= candle_end
                if closed.any():
                    idx = closed[closed].index[-1]
                    pos_idx = df75.index.get_loc(idx)
                    ema_val = float(ema_col.iloc[pos_idx])
                    if ema_val > 0:
                        diff = (close - ema_val) / ema_val * 100.0
                        out["ema75"] = {
                            "state": "ABOVE" if close >= ema_val else "BELOW",
                            "ema": round(ema_val, 2),
                            "dist_pct": round(abs(diff), 2),
                            "period": p,
                            "bar_start": str(df75.loc[idx, "timestamp"]),
                        }
        except Exception as e:
            print(f"75-min EMA position failed for {signal.get('symbol')}: {e}")

        # ---- 1 month ----
        if mv and mv.get("month_high") is not None and mv.get("month_low") is not None:
            out["month"] = _range_position(close, float(mv["month_high"]), float(mv["month_low"]))
    except Exception as e:
        print(f"compute_position_info failed for {signal.get('symbol')}: {e}")
    return out


def get_sector_trend(df):
    """
    Sector-index trend reading (added) — same rule the stock-level
    trend uses (stock_trend in _evaluate_candle): close above EMA50 =
    UPTREND, close below = DOWNTREND. No cross logic, no filters, just
    the current trend on the sector index's own 3-min data. Meant to be
    called on a sector index's df3 (today's 1-min resampled to 3-min,
    same as any stock) and attached to a related stock's alert in
    main.py via config.STOCK_SECTOR_MAP.

    Returns None if there isn't enough 3-min history yet today to warm
    up EMA50 (same ~50-candle / ~150-minute-into-session constraint the
    main per-stock signal already has) — the caller treats None as
    "not available yet", never an error.
    """
    if len(df) < 51:
        return None
    df = add_ema50(df)
    curr = df.iloc[-1]
    return "UPTREND" if curr["close"] > curr["ema_trend"] else "DOWNTREND"


def check_signals_15min(df_15min, symbol, lookback=None):
    """
    STANDALONE 15-min alert — pure EMA9/EMA20 crossover on the 15-min
    chart. Same design as the retired standalone 75-min alert used to
    be: no strong-candle filter, no EMA50 trend-agreement requirement,
    no min-gap filter. Intended for config.COMMODITIES only (see
    main.py — the caller filters by symbol), so it is not restricted
    here. Fires independently of check_signals(). Deduped separately
    in main.py with state key namespaced "::15m".

    Uses the same catch-up-window approach: scans the last `lookback`
    closed 15-min candles (default: config.CROSS_LOOKBACK_CANDLES), not
    just the latest one.

    Returns a list of signal dicts (oldest first), each tagged
    timeframe="15-min". Empty list if nothing qualifies or there isn't
    enough 15-min history yet.
    """
    lookback = lookback or config.CROSS_LOOKBACK_CANDLES

    if len(df_15min) < config.EMA_SLOW + 2:
        return []

    max_possible_lookback = len(df_15min) - (config.EMA_SLOW + 1)
    lookback = max(1, min(lookback, max_possible_lookback))

    df = add_emas(df_15min, config.EMA_FAST, config.EMA_SLOW)
    df = add_rsi(df, config.RSI_PERIOD)
    df = add_volume_avg(df, config.VOLUME_AVG_PERIOD)

    signals = []
    n = len(df)
    start = max(1, n - lookback)
    for idx in range(start, n):
        curr = df.iloc[idx]
        prev = df.iloc[idx - 1]

        bullish_cross = prev["ema_fast"] <= prev["ema_slow"] and curr["ema_fast"] > curr["ema_slow"]
        bearish_cross = prev["ema_fast"] >= prev["ema_slow"] and curr["ema_fast"] < curr["ema_slow"]

        if not (bullish_cross or bearish_cross):
            continue

        direction = "BULLISH" if bullish_cross else "BEARISH"

        curr_vol = curr["volume"]
        prev_vol = prev["volume"]
        vol_change_pct = round(((curr_vol - prev_vol) / prev_vol) * 100, 1) if prev_vol else None
        rsi_val = curr["rsi"] if not pd_isna(curr["rsi"]) else None

        cross_pattern = detect_candle_pattern(curr)
        prev_pattern = detect_candle_pattern(prev)

        signals.append({
            "symbol": symbol,
            "timeframe": "15-min",
            "direction": direction,
            "close": round(float(curr["close"]), 2),
            "rsi": round(float(rsi_val), 1) if rsi_val is not None else None,
            "volume": int(curr["volume"]),
            "vol_avg": round(float(curr["vol_avg"]), 0) if not pd_isna(curr["vol_avg"]) else None,
            "vol_change_pct": vol_change_pct,
            "ema_fast": round(float(curr["ema_fast"]), 2),
            "ema_slow": round(float(curr["ema_slow"]), 2),
            "candle_time": str(curr.get("timestamp", "")),
            "cross_candle_pattern": cross_pattern,
            "prev_candle_pattern": prev_pattern,
        })

    return signals


def passes_confluence_filter(signal):
    """
    Secondary quality filter layered ONLY on top of an already-
    qualifying 75-min EMA cross signal (stocks/commodities/Nifty 500 —
    never applied to index or VWAP-momentum alerts, which have their
    own separate rules). Combines fields the signal ALREADY carries
    (entry/stop_loss/target/risk_reward from _evaluate_candle, plus
    sector_trend/oi_buildup attached later in main.py) into a single
    "is this a genuinely good risk:reward setup" gate — no new
    indicator, no extra API call:

      1. risk_reward (entry vs the EMA-based stop vs the trailing
         config.TARGET_LOOKBACK_CANDLES high/low target) must be at
         least config.CONFLUENCE_MIN_RISK_REWARD — this is what keeps
         the stop small relative to the target.
      2. RSI must sit in a "trending but not yet exhausted" band —
         BULLISH: config.CONFLUENCE_RSI_BULLISH_MIN..MAX (skips a
         cross that's already overbought and due a pullback); BEARISH:
         config.CONFLUENCE_RSI_BEARISH_MIN..MAX (mirror — skips
         shorting into an already-oversold bounce).
      3. sector_trend (if the stock has a sector mapping — see
         config.STOCK_SECTOR_MAP) must agree with the signal
         direction. Stocks/instruments with no sector mapping, or no
         sector reading yet, simply skip this check (neither pass nor
         fail on it).
      4. oi_buildup bias (F&O stocks only, fetched on-demand in
         main.py — see get_stock_oi_buildup) must not OPPOSE the
         direction — a BEARISH (call-writing-dominant) buildup blocks
         a BULLISH signal and vice versa. NEUTRAL, or no buildup
         reading yet, both pass.

    Returns True/False. Only ever called on a signal that has ALREADY
    passed check_signals()'s own mandatory conditions (cross + EMA50
    trend agreement + volume increase) — this is an additional,
    optional layer on top, controlled by config.CONFLUENCE_FILTER_ENABLED.
    """
    risk_reward = signal.get("risk_reward")
    if config.CONFLUENCE_CHECK_RISK_REWARD:
        if risk_reward is None or risk_reward < config.CONFLUENCE_MIN_RISK_REWARD:
            return False

    rsi_val = signal.get("rsi")
    if config.CONFLUENCE_CHECK_RSI_BAND:
        if rsi_val is None:
            return False
        if signal["direction"] == "BULLISH":
            if not (config.CONFLUENCE_RSI_BULLISH_MIN <= rsi_val <= config.CONFLUENCE_RSI_BULLISH_MAX):
                return False
        else:
            if not (config.CONFLUENCE_RSI_BEARISH_MIN <= rsi_val <= config.CONFLUENCE_RSI_BEARISH_MAX):
                return False

    sector_trend = signal.get("sector_trend")
    if config.CONFLUENCE_CHECK_SECTOR_TREND and sector_trend is not None:
        expected = "UPTREND" if signal["direction"] == "BULLISH" else "DOWNTREND"
        if sector_trend != expected:
            return False

    oi_buildup = signal.get("oi_buildup")
    if config.CONFLUENCE_CHECK_OI_BUILDUP and oi_buildup is not None:
        bias = oi_buildup.get("bias")
        opposing = "BEARISH" if signal["direction"] == "BULLISH" else "BULLISH"
        if bias == opposing:
            return False

    return True


def compute_smart_money_signal(signal):
    """
    "Smart Money Entry" 🐋 — PURELY INFORMATIONAL, added per request
    (and made non-blocking from the start, matching the rest of the
    codebase's now-informational-everywhere style — OI buildup itself
    was also switched from blocking to informational, see
    CONFLUENCE_CHECK_OI_BUILDUP). Never stops an alert from being
    sent; only adds a tag + reasons line when several independent
    signs line up. Built entirely from fields the signal ALREADY
    carries by the time this is called (see main.py — delivery%,
    Bulk/Block deal, sector/OI, Momentum, Volume Spike, and EMA50/200
    are all attached before this runs) — no new fetch, no extra API
    call.

    Up to 9 points, 1 each:
      1. OI buildup bias agrees with the signal direction (F&O stocks
         only — cash-only Nifty 500 scan never sets this, so it's
         simply skipped there, same as every other missing field below)
      2. Crossing candle's volume beat the previous candle's
         (vol_change_pct > 0)
      3. delivery_pct >= config.SMART_MONEY_DELIVERY_THRESHOLD (prev
         trading day's NSE delivery %, not a per-stock trailing
         average)
      4. VWAP cushion: BULLISH needs Close >= VWAP by at least
         config.SMART_MONEY_VWAP_MIN_PCT; BEARISH the mirror
      5. A same-direction Bulk/Block deal (BUY for BULLISH, SELL for
         BEARISH) dated within config.SMART_MONEY_DEAL_LOOKBACK_DAYS
         calendar days of the signal's candle_time
      6. cross_candle_pattern is a Marubozu matching the direction
      7. Momentum: signal["momentum"] is True (today's close above the
         trailing 4-week high — see main.py's build_momentum_volume_data)
      8. Volume Spike: signal["volume_spike"] is True (yesterday's
         volume beat the volume from 5 trading days before that)
      9. EMA50/200 (daily) bias agrees with the signal direction —
         signal["ema_cross"]["bias"]

    Returns None if fewer than config.SMART_MONEY_MIN_SCORE points are
    scored (out of however many of the 9 dimensions actually had data
    available this run — missing fields are skipped, not counted
    against it); otherwise {"score": int, "possible": int,
    "reasons": [str, ...]}.
    """
    direction = signal["direction"]
    score = 0
    possible = 0
    reasons = []

    # ---- 1. OI buildup direction ----
    oi_buildup = signal.get("oi_buildup")
    if oi_buildup:
        possible += 1
        if oi_buildup.get("bias") == direction:
            score += 1
            reasons.append(f"OI buildup: {direction.title()}")

    # ---- 2. volume beat previous candle ----
    vol_change_pct = signal.get("vol_change_pct")
    if vol_change_pct is not None:
        possible += 1
        if vol_change_pct > 0:
            score += 1
            reasons.append(f"Volume up {vol_change_pct:+.1f}% vs previous candle")

    # ---- 3. delivery % ----
    deliv = signal.get("delivery_pct")
    if deliv is not None:
        possible += 1
        if deliv >= config.SMART_MONEY_DELIVERY_THRESHOLD:
            score += 1
            reasons.append(f"Delivery {deliv:.1f}% (>={config.SMART_MONEY_DELIVERY_THRESHOLD:.0f}%)")

    # ---- 4. VWAP cushion ----
    vwap = signal.get("vwap")
    close = signal.get("close")
    if vwap and close:
        possible += 1
        gap_pct = (close - vwap) / vwap * 100
        if direction == "BULLISH" and gap_pct >= config.SMART_MONEY_VWAP_MIN_PCT:
            score += 1
            reasons.append(f"Above VWAP by {gap_pct:+.2f}%")
        elif direction == "BEARISH" and gap_pct <= -config.SMART_MONEY_VWAP_MIN_PCT:
            score += 1
            reasons.append(f"Below VWAP by {gap_pct:+.2f}%")

    # ---- 5. same-direction Bulk/Block deal, recent ----
    deal = signal.get("last_bulk_block_deal")
    if deal and deal.get("date") and signal.get("candle_time"):
        possible += 1
        expected_side = "BUY" if direction == "BULLISH" else "SELL"
        if (deal.get("buy_sell") or "").upper() == expected_side:
            deal_dt = _parse_deal_date(deal["date"])
            candle_dt = _parse_candle_time(signal["candle_time"])
            if deal_dt is not None and candle_dt is not None:
                if 0 <= (candle_dt.date() - deal_dt.date()).days <= config.SMART_MONEY_DEAL_LOOKBACK_DAYS:
                    score += 1
                    reasons.append(f"{deal['type']} deal ({expected_side}) on {deal['date']}")

    # ---- 6. strong matching Marubozu ----
    pattern = signal.get("cross_candle_pattern")
    if pattern:
        possible += 1
        expected_pattern = "Bullish Marubozu" if direction == "BULLISH" else "Bearish Marubozu"
        if pattern == expected_pattern:
            score += 1
            reasons.append(f"Crossing candle: {pattern}")

    # ---- 7. Momentum (4-week high) ----
    momentum = signal.get("momentum")
    if momentum is not None:
        possible += 1
        if momentum:
            score += 1
            reasons.append(f"Momentum: above 4-week high ({signal.get('four_week_high_close')})")

    # ---- 8. Volume Spike (vs 5 trading days ago) ----
    volume_spike = signal.get("volume_spike")
    if volume_spike is not None:
        possible += 1
        if volume_spike:
            score += 1
            reasons.append("Volume spike: prev day vol > 5-day-ago vol")

    # ---- 9. EMA50/200 (daily) bias ----
    ema_cross = signal.get("ema_cross")
    if ema_cross:
        possible += 1
        if ema_cross.get("bias") == direction:
            score += 1
            reasons.append(f"EMA50/200 (daily): {ema_cross['bias'].title()}")

    if score < config.SMART_MONEY_MIN_SCORE:
        return None

    return {"score": score, "possible": possible, "reasons": reasons}


def _parse_deal_date(date_str):
    for fmt in ("%d-%b-%Y", "%d-%B-%Y"):
        try:
            return _dt.datetime.strptime(date_str.strip(), fmt)
        except Exception:
            continue
    return None


def _parse_candle_time(candle_time_str):
    # candle_time is str(pandas_timestamp), e.g. "2026-08-15 13:00:00"
    # or "2026-08-15 13:00:00+05:30" -- take just the date portion,
    # first 10 chars, which is always "YYYY-MM-DD" regardless of
    # whatever comes after.
    try:
        return _dt.datetime.strptime(candle_time_str[:10], "%Y-%m-%d")
    except Exception:
        return None


def check_vwap_momentum(df5, symbol, lookback=None):
    """
    Standalone BUY-side momentum scan — replicates a Chartink "VWAP EMA
    9,20 RSI" screener (uploaded screenshot, 2026-08-11): on the 5-min
    chart of an F&O futures-segment stock, fires once when ALL of these
    newly become true on a closed 5-min candle:
      1. 5-min RSI(14) > config.VWAP_MOMENTUM_RSI_MIN
      2. Day's Close / Day's Open > config.VWAP_MOMENTUM_DAY_CHANGE_MIN
         (today's cumulative move up from the day's opening price)
      3. Day's VWAP < the 5-min candle's Close (price trading above the
         day's volume-weighted average price)
      4. Day's cumulative Volume >= config.VWAP_MOMENTUM_MIN_VOLUME
      5. Day's Close > config.VWAP_MOMENTUM_MIN_PRICE

    "Day's Open/Close/Volume/VWAP" are all computed cumulatively from
    df5 (Upstox intraday data = current session only, so row 0 already
    is the session's first 5-min bar — same assumption
    _compute_vwap_at already relies on elsewhere in this file).

    Transition-only firing: a candle only qualifies if ALL conditions
    are true on it AND at least one condition was false on the
    immediately preceding candle (or there's no prior candle in the
    lookback window to compare) — otherwise the scan would re-alert on
    every single run for as long as the stock stays in the qualifying
    zone. main.py's candle_time-keyed state dedup is a second safety
    net on top of this.

    Returns a list of signal dicts (oldest first), each tagged
    timeframe="5-min", direction="BULLISH" (this is a buy-only screen,
    matching the Chartink scan it replicates). Empty list if nothing
    qualifies or there isn't enough 5-min history yet today.
    """
    if df5 is None or len(df5) < config.VWAP_MOMENTUM_RSI_PERIOD + 2:
        return []

    lookback = lookback or config.INDEX_ALERT_LOOKBACK_CANDLES
    df = df5.copy()
    df = add_rsi(df, config.VWAP_MOMENTUM_RSI_PERIOD)

    day_open = float(df.iloc[0]["open"])
    if day_open <= 0:
        return []

    n = len(df)
    start = max(1, n - lookback)

    def _qualifies(idx):
        row = df.iloc[idx]
        rsi_val = row["rsi"]
        if pd_isna(rsi_val):
            return False
        day_close = float(row["close"])
        day_volume = float(df.iloc[: idx + 1]["volume"].sum())
        day_vwap = _compute_vwap_at(df, idx)
        if day_vwap is None:
            return False
        return (
            float(rsi_val) > config.VWAP_MOMENTUM_RSI_MIN
            and (day_close / day_open) > config.VWAP_MOMENTUM_DAY_CHANGE_MIN
            and day_vwap < day_close
            and day_volume >= config.VWAP_MOMENTUM_MIN_VOLUME
            and day_close > config.VWAP_MOMENTUM_MIN_PRICE
        )

    signals = []
    for idx in range(start, n):
        if not _qualifies(idx):
            continue
        if idx > 0 and _qualifies(idx - 1):
            continue  # already qualifying last candle too — not a fresh trigger

        curr = df.iloc[idx]
        rsi_val = float(curr["rsi"])
        day_close = float(curr["close"])
        day_volume = float(df.iloc[: idx + 1]["volume"].sum())
        day_vwap = _compute_vwap_at(df, idx)

        signals.append({
            "symbol": symbol,
            "timeframe": "5-min",
            "direction": "BULLISH",
            "scan_type": "vwap_momentum",
            "close": round(day_close, 2),
            "day_open": round(day_open, 2),
            "day_change_pct": round((day_close / day_open - 1) * 100, 2),
            "vwap": round(day_vwap, 2),
            "rsi": round(rsi_val, 1),
            "volume": int(day_volume),
            "candle_time": str(curr.get("timestamp", "")),
        })

    return signals


def pd_isna(val):
    import pandas as pd
    return pd.isna(val)


def compute_session_vwap(df):
    """
    Public wrapper around _compute_vwap_at for the LATEST row of `df`
    — the cumulative session VWAP as of the most recent candle. Used
    by run_breakout_scan (main.py) on today's full-day 5-min candles
    to get today's session VWAP for Row 13 ("Bulls in charge": Close >
    VWAP). Returns None if df is empty or has zero cumulative volume.
    """
    if df is None or len(df) == 0:
        return None
    return _compute_vwap_at(df, len(df) - 1)


def compute_consolidation_window(history):
    """
    Consolidation Breakout (added, per request — "Consolidation dhorte
    parbe?") — checks whether the trailing config.CONSOLIDATION_
    LOOKBACK_DAYS COMPLETED trading days (from `history`, which already
    excludes today — see main.fetch_daily_history) have been trading in
    a TIGHT range, i.e. "coiling" before a potential breakout.

    Tight means (highest HIGH - lowest LOW) over the window, as a % of
    the window's average CLOSE, is <= config.CONSOLIDATION_MAX_RANGE_PCT.
    A wide/trending window (not actually consolidating) returns None —
    there's nothing meaningful to break out of.

    Returns None if there isn't enough history yet, or the window
    wasn't actually tight. Otherwise:
      {"range_low": float, "range_high": float, "range_pct": float,
       "avg_volume": float, "days": int}
    range_low/range_high are the window's lowest LOW / highest HIGH —
    the actual breakout levels a later close needs to clear. avg_volume
    is the window's average daily volume, the baseline a breakout
    candle's volume is compared against (see
    check_consolidation_breakout_live / check_consolidation_breakout_scan
    below).
    """
    lookback = config.CONSOLIDATION_LOOKBACK_DAYS
    if len(history) < lookback:
        return None

    window = history[-lookback:]
    range_high = max(day["high"] for day in window)
    range_low = min(day["low"] for day in window)
    avg_close = sum(day["close"] for day in window) / len(window)
    if avg_close <= 0:
        return None

    range_pct = (range_high - range_low) / avg_close * 100
    if range_pct > config.CONSOLIDATION_MAX_RANGE_PCT:
        return None

    avg_volume = sum(day["volume"] for day in window) / len(window)

    return {
        "range_low": range_low,
        "range_high": range_high,
        "range_pct": round(range_pct, 2),
        "avg_volume": avg_volume,
        "days": lookback,
    }


def _consolidation_breakout_from(symbol, close, volume, cw):
    """Shared breakout-decision logic for the live and EOD checks
    below — both just supply `close`/`volume` from a different source
    (today-so-far vs. today's finalized daily bar) and get back the
    same signal shape."""
    if not cw:
        return None

    volume_multiple = round(volume / cw["avg_volume"], 2) if cw["avg_volume"] else 0
    if volume_multiple < config.CONSOLIDATION_BREAKOUT_MIN_VOLUME_MULTIPLE:
        return None

    if close > cw["range_high"]:
        direction = "BULLISH"
    elif close < cw["range_low"]:
        direction = "BEARISH"
    else:
        return None

    return {
        "symbol": symbol,
        "direction": direction,
        "close": close,
        "range_low": cw["range_low"],
        "range_high": cw["range_high"],
        "range_pct": cw["range_pct"],
        "volume_multiple": volume_multiple,
    }


def check_consolidation_breakout_live(symbol, current_close, current_volume_so_far, cw):
    """
    LIVE (intraday) Consolidation Breakout check (added, per request —
    "emergency alert e add kora jay na", i.e. check this every scan
    cycle in the main real-time loop, not just once/day at close). `cw`
    is the consolidation window from compute_consolidation_window
    (already computed once/day from cached daily history — see
    main.build_momentum_volume_data). Fires the moment TODAY's current
    price/volume-so-far breaks the window, without waiting for today's
    candle to close.

    NOTE: current_volume_so_far is only PART of today's eventual
    full-day volume (however much of the session has elapsed so far),
    while cw["avg_volume"] is a FULL-DAY average from the consolidation
    window — so the volume_multiple this produces UNDERSTATES the
    likely end-of-day multiple, especially early in the session. This
    is a deliberate simplification (no time-of-day elapsed-fraction
    scaling) — treat an early-session volume_multiple as a floor, not
    the final number; it only gets more accurate as the day progresses.

    Returns None if cw is None, volume confirmation fails, or price
    hasn't broken either side of the range yet. Otherwise a signal
    dict: {"symbol", "direction" ("BULLISH"/"BEARISH"), "close",
    "range_low", "range_high", "range_pct", "volume_multiple"} — same
    shape check_consolidation_breakout_scan returns, so both feed
    telegram_notifier.send_consolidation_breakout_summary identically.
    """
    return _consolidation_breakout_from(symbol, current_close, current_volume_so_far, cw)


def check_consolidation_breakout_scan(history, today_bar, symbol):
    """
    EOD (once/day, after close) Consolidation Breakout check (added,
    per request). Computes the consolidation window from `history`
    (pre-today daily candles — see main.fetch_daily_history) via
    compute_consolidation_window, then checks whether TODAY's own close
    (today_bar, from main.build_todays_daily_bar) broke out of it, with
    volume confirmation.

    Unlike check_consolidation_breakout_live, today_bar["volume"] is
    genuinely today's FULL session volume (this scan runs at/after
    market close), so this volume_multiple is accurate, not a
    lower-bound estimate.

    Returns None if there's no consolidation window (not enough
    history, or the window wasn't actually tight), volume confirmation
    fails, or today's close didn't break either side. Otherwise the
    same signal shape as check_consolidation_breakout_live.
    """
    cw = compute_consolidation_window(history)
    return _consolidation_breakout_from(symbol, today_bar["close"], today_bar["volume"], cw)


def check_breakout_scan(history, today_bar, symbol):
    """
    12-condition daily breakout screener (Chartink-style scan supplied
    2026-08-18), Row 2 (Market Cap) omitted — no data source in this
    bot (see chat). ALL 12 must pass for a signal to fire:

      1.  Close > config.BREAKOUT_MIN_PRICE
      3.  Close * Volume > config.BREAKOUT_MIN_TURNOVER
      4.  Volume > MULTIPLIER * 20-day-avg-Volume AS OF YESTERDAY
      5.  Close > 50-day SMA (including today)
      6.  Close > 200-day SMA (including today)
      7.  RSI(14) > BREAKOUT_RSI_MIN
      8.  RSI(14) < BREAKOUT_RSI_MAX
      9.  Close >= PCT * 250-day-High AS OF YESTERDAY
      10. Close > 20-day-High AS OF YESTERDAY
      11. (10-day High - 10-day Low) < PCT * Close (including today)
      12. ATR(14) > PCT * Close (including today)
      13. Close > today's session VWAP

    "AS OF YESTERDAY" = computed over `history` alone (which already
    excludes today — see main.fetch_daily_history), matching the
    Chartink build's "offset: 1 day ago" gear-icon setting on those
    three terms. Every other rolling stat is computed over
    `history + [today_bar]` (i.e. including today), matching the rows
    that had NO offset specified.

    history: list of {"date","open","high","low","close","volume"},
    oldest -> newest, strictly BEFORE today (main.fetch_daily_history's
    output).
    today_bar: {"date","open","high","low","close","volume","vwap"} for
    today, built from today's own intraday session (see
    main.build_todays_daily_bar). vwap may be None if today's intraday
    fetch failed/is empty — Row 13 then just fails gracefully (no
    signal), same as any other missing-data case in this bot.

    Returns a signal dict (all 12 conditions' raw numbers included, for
    the alert message) if every condition passes, else None. Returns
    None immediately if there isn't enough daily history yet for the
    250-day lookback to be meaningful.
    """
    needed = max(config.BREAKOUT_NEAR_HIGH_LOOKBACK_DAYS, config.BREAKOUT_SMA_LONG_PERIOD)
    if len(history) < needed or today_bar is None:
        return None

    hist_df = pd.DataFrame(history)

    # ---- "AS OF YESTERDAY" stats (history only, today excluded) ----
    vol_sma20_yday = float(hist_df["volume"].iloc[-config.BREAKOUT_VOLUME_SMA_PERIOD:].mean())
    high_250_yday = float(hist_df["high"].iloc[-config.BREAKOUT_NEAR_HIGH_LOOKBACK_DAYS:].max())
    high_20_yday = float(hist_df["high"].iloc[-config.BREAKOUT_NEW_HIGH_LOOKBACK_DAYS:].max())

    # ---- "INCLUDING TODAY" stats (history + today_bar) ----
    combined = history + [today_bar]
    cdf = pd.DataFrame(combined)
    if len(cdf) < config.BREAKOUT_SMA_LONG_PERIOD:
        return None

    sma50 = float(cdf["close"].iloc[-config.BREAKOUT_SMA_SHORT_PERIOD:].mean())
    sma200 = float(cdf["close"].iloc[-config.BREAKOUT_SMA_LONG_PERIOD:].mean())

    cdf = add_rsi(cdf, config.BREAKOUT_RSI_PERIOD)
    rsi_today = cdf["rsi"].iloc[-1]

    cdf = add_atr(cdf, config.BREAKOUT_ATR_PERIOD)
    atr_today = cdf["atr"].iloc[-1]

    tight_window = cdf.iloc[-config.BREAKOUT_TIGHT_BASE_LOOKBACK_DAYS:]
    tight_base_range = float(tight_window["high"].max() - tight_window["low"].min())

    close_today = float(today_bar["close"])
    volume_today = float(today_bar["volume"])
    turnover_today = close_today * volume_today
    vwap_today = today_bar.get("vwap")

    if pd.isna(rsi_today) or pd.isna(atr_today):
        return None
    rsi_today = float(rsi_today)
    atr_today = float(atr_today)

    checks = {
        "price_floor":       close_today > config.BREAKOUT_MIN_PRICE,
        "turnover":          turnover_today > config.BREAKOUT_MIN_TURNOVER,
        "volume_spike":      vol_sma20_yday > 0 and volume_today > (config.BREAKOUT_VOLUME_SPIKE_MULTIPLIER * vol_sma20_yday),
        "above_sma50":       close_today > sma50,
        "above_sma200":      close_today > sma200,
        "rsi_floor":         rsi_today > config.BREAKOUT_RSI_MIN,
        "rsi_ceiling":       rsi_today < config.BREAKOUT_RSI_MAX,
        "near_52w_high":     high_250_yday > 0 and close_today >= (config.BREAKOUT_NEAR_HIGH_PCT * high_250_yday),
        "new_breakout_high": high_20_yday > 0 and close_today > high_20_yday,
        "tight_base":        tight_base_range < (config.BREAKOUT_TIGHT_BASE_MAX_RANGE_PCT * close_today),
        "enough_volatility": atr_today > (config.BREAKOUT_ATR_MIN_PCT * close_today),
        "above_vwap":        vwap_today is not None and close_today > vwap_today,
    }

    if not all(checks.values()):
        return None

    return {
        "symbol": symbol,
        "date": today_bar["date"],
        "close": round(close_today, 2),
        "volume": int(volume_today),
        "turnover_cr": round(turnover_today / 1e7, 1),
        "sma50": round(sma50, 2),
        "sma200": round(sma200, 2),
        "rsi": round(rsi_today, 1),
        "high_250d": round(high_250_yday, 2),
        "pct_of_52w_high": round((close_today / high_250_yday) * 100, 1),
        "high_20d": round(high_20_yday, 2),
        "tight_base_range_pct": round((tight_base_range / close_today) * 100, 2),
        "atr": round(atr_today, 2),
        "atr_pct": round((atr_today / close_today) * 100, 2),
        "vwap": round(vwap_today, 2),
        "checks": checks,
    }


def compute_intraday_checklist(signal):
    """
    "15-Minute Intraday Trade Checklist" (added, per request) — a
    fixed 0-10 point checklist, purpose-built for entry timing rather
    than overall alert quality (Trade Score, the earlier variable-
    denominator /10 rollup this once sat alongside, was removed per a
    later request — this checklist is the only score left on the
    alert).

    CHANGED (per request, 2026-08-27 — "1st 15 minit candle open =
    low/high sorao... smart money-r momentum ar volume spike-ta add
    kore score generate korle kemon hoy"): the old "1st 15-min candle
    Open = Low/High" item (2 pts) is REMOVED — it's a static fact
    fixed at 09:30 that stays the same all day, so on a cross that
    fires hours later (this is now the 15-min primary timeframe) it
    was really just re-scoring "how the morning opened," not this
    candle's setup. In its place, two fields already computed for
    Smart Money are folded in here too (1 pt each): Momentum and
    Volume Spike. Total is still a fixed /10.

    Mirrors automatically for BULLISH (BUY setup) vs BEARISH (SELL
    setup) signals -- same checks, opposite direction each time:

      BUY SETUP (BULLISH)                    SELL SETUP (BEARISH)
      EMA9 > EMA20            +1             EMA9 < EMA20            +1
      Price > VWAP            +1             Price < VWAP            +1
      Crossing vol > prev     +1             Crossing vol > prev     +1
      Volume > recent avg     +1             Volume > recent avg     +1
      MACD bullish            +1             MACD bearish            +1
      RSI > 50                +1             RSI < 50                +1
      Momentum (4-wk high)    +1             No fresh 4-wk high      +1
      Volume Spike (vs 5d ago)+1             Volume Spike (vs 5d ago)+1
      1st 15-min High breakout+2             1st 15-min Low breakdown+2

    Momentum note: signal["momentum"] only ever means "today's close
    is above the trailing 4-week high" (see main.py's
    build_momentum_volume_data) -- there's no separate "4-week low"
    tracked for a bearish mirror. So for a BEARISH signal this check
    instead rewards momentum being False, i.e. price is NOT currently
    making a fresh high -- read it as "no fresh breakout strength
    working against this short," not a true bearish-momentum measure.
    If that framing doesn't feel right for how you trade shorts, this
    is the one item worth reconsidering / dropping back out.

    Volume Spike (yesterday's volume vs. 5 trading days before that)
    is direction-agnostic on purpose -- it flags unusual volume
    interest in the stock generally, which is treated as supportive
    context either direction, same as the "Crossing vol > prev" /
    "Volume > recent avg" checks already here.

    This is NOT rescaled by how many dimensions had data -- every
    check always counts (missing/unavailable data just means that
    check is simply not satisfied, i.e. 0 points for it, same as a
    real "no"), so the denominator is always a fixed /10 and directly
    comparable across every alert.

    Reads only fields the signal already carries (from _evaluate_candle,
    main.py's opening_candle_bias/momentum/volume_spike attachment) --
    no extra fetch. IMPORTANT: momentum/volume_spike must be attached
    to the signal BEFORE this is called (main.py now does this).
    Returns {"score": int (0-10), "label": "X/10", "items": [(name,
    checked_bool, points), ...]} -- "items" is the tickable checklist
    itself, in the same top-to-bottom order as specified, for
    telegram_notifier to render as [ ]/[x] lines if desired.
    """
    direction = signal["direction"]
    bullish = direction == "BULLISH"

    ema_fast, ema_slow = signal.get("ema_fast"), signal.get("ema_slow")
    ema_ok = ema_fast is not None and ema_slow is not None and (
        ema_fast > ema_slow if bullish else ema_fast < ema_slow
    )

    close, vwap = signal.get("close"), signal.get("vwap")
    vwap_ok = close is not None and vwap is not None and (
        close > vwap if bullish else close < vwap
    )

    vol_change_pct = signal.get("vol_change_pct")
    vol_vs_prev_ok = vol_change_pct is not None and vol_change_pct > 0

    volume, vol_avg = signal.get("volume"), signal.get("vol_avg")
    vol_vs_avg_ok = volume is not None and vol_avg is not None and volume > vol_avg

    # CHANGED (per request): must be a genuinely RECENT MACD line/
    # signal crossover within config.MACD_DIVERGENCE_LOOKBACK_CANDLES,
    # not just today's current MACD level — see
    # strategy._detect_macd_cross_recent.
    macd_cross_recent = signal.get("macd_cross_recent")
    macd_ok = macd_cross_recent == ("BULLISH" if bullish else "BEARISH")

    rsi = signal.get("rsi")
    rsi_ok = rsi is not None and (rsi > 50 if bullish else rsi < 50)

    momentum = signal.get("momentum")
    momentum_ok = momentum is not None and (momentum if bullish else not momentum)

    volume_spike = signal.get("volume_spike")
    volume_spike_ok = volume_spike is True

    opening_breakout = signal.get("opening_range_breakout")
    opening_breakout_ok = opening_breakout == ("BULLISH" if bullish else "BEARISH")

    items = [
        ("EMA9 > EMA20" if bullish else "EMA9 < EMA20", ema_ok, 1),
        ("Price > VWAP" if bullish else "Price < VWAP", vwap_ok, 1),
        ("Crossing candle volume > previous candle", vol_vs_prev_ok, 1),
        ("Volume clearly above recent average", vol_vs_avg_ok, 1),
        ("MACD bullish cross (recent)" if bullish else "MACD bearish cross (recent)", macd_ok, 1),
        ("RSI > 50" if bullish else "RSI < 50", rsi_ok, 1),
        ("Momentum: above 4-week high" if bullish else "No fresh 4-week high (momentum not against short)", momentum_ok, 1),
        ("Volume Spike (vs. 5 trading days ago)", volume_spike_ok, 1),
        ("1st 15-min High breakout, close above High" if bullish
         else "1st 15-min Low breakdown, close below Low", opening_breakout_ok, 2),
    ]

    score = sum(points for _, checked, points in items if checked)

    return {
        "score": score,
        "label": f"{score}/10",
        "items": items,
    }



def compute_near_high_score(signal):
    """
    "Near N-month High" (added, per request — "1 to 6 month high show
    korabe, price jodi high er kache thake to trading score point jog
    hobe") — checks whether the current close is within
    config.NEAR_HIGH_THRESHOLD_PCT (5%) of ANY of the 1-6 month highs
    already computed in main.py's build_momentum_volume_data
    (signal["multi_month_highs"] = {1: high, 2: high, ..., 6: high},
    highest daily HIGH over each trailing N-month window). Whichever
    of the 6 months is numerically closest to today's close is the one
    reported — a stock can be "near" more than one month's high at
    once (e.g. if it's been flat for months), only the closest matters.

    Unlike Momentum (signal["momentum"], which only fires when close
    BREAKS ABOVE the 4-week high), this fires on APPROACH too — being
    2% below a 6-month high is exactly the kind of "coiling near
    resistance" setup this is meant to flag, not just actual breakouts.

    Checked regardless of alert direction (BULLISH or BEARISH) — same
    treatment as Daily Score's checks, which are always bullish-quality
    framed regardless of the signal's own direction.

    Returns None if signal["multi_month_highs"] isn't present/empty
    (not enough daily history yet for this symbol — same graceful
    degradation as every other optional field). Otherwise:
      {"score": 1 or 0, "possible": 1, "nearest_month": int (1-6),
       "nearest_high": float, "gap_pct": float}
    gap_pct is signed: negative means close is below that month's
    high, positive means close is already above it.
    """
    multi_month_highs = signal.get("multi_month_highs")
    close = signal.get("close")
    if not multi_month_highs or close is None:
        return None

    nearest_month, nearest_high, nearest_gap_pct = None, None, None
    for months, high in multi_month_highs.items():
        if high <= 0:
            continue
        gap_pct = (close - high) / high * 100
        if nearest_gap_pct is None or abs(gap_pct) < abs(nearest_gap_pct):
            nearest_month, nearest_high, nearest_gap_pct = months, high, gap_pct

    if nearest_month is None:
        return None

    is_near = abs(nearest_gap_pct) <= config.NEAR_HIGH_THRESHOLD_PCT
    return {
        "score": 1 if is_near else 0,
        "possible": 1,
        "nearest_month": nearest_month,
        "nearest_high": nearest_high,
        "gap_pct": round(nearest_gap_pct, 2),
    }


def compute_trading_score(signal):
    """
    "Trading Score" (added, per request — "sob miliye ekta trading
    score generate koro") — ONE combined /10 score that rolls up the
    four separate scores/checks already on the alert, so there's a
    single number to glance at before deciding whether to take the
    trade:

      - Buy/Sell Score (intraday_checklist — entry timing, fixed /10)
      - Daily Score (bullish-quality checklist, fixed /8)
      - Smart Money (institutional confirmation, variable /possible —
        stocks only, not present on index alerts, and only present at
        all when it scored >= config.SMART_MONEY_MIN_SCORE)
      - Near N-month High (added, per request — 1 point if close is
        within config.NEAR_HIGH_THRESHOLD_PCT of any 1-6 month high,
        see compute_near_high_score)

    Each present component is normalized to a common /10 scale, then
    averaged with EQUAL weight across however many components are
    actually available on this particular signal. A missing component
    (e.g. Smart Money didn't qualify this run, or multi_month_highs
    wasn't available yet) is simply left out of the average — not
    counted as 0 — so alerts with fewer available components are still
    scored fairly on whatever they do have.

    Returns None only if neither the checklist nor daily_score is
    attached yet (shouldn't happen in practice — both are always set
    on a signal before this is called). Otherwise:
      {"score": float (0-10, 1 decimal), "label": str}
    label bands: 8-10 STRONG, 6-7.9 GOOD, 4-5.9 MODERATE, <4 WEAK.
    """
    checklist = signal.get("intraday_checklist")
    daily_score = signal.get("daily_score")
    smart_money = signal.get("smart_money")
    near_high = signal.get("near_high")

    parts = []
    if checklist is not None:
        parts.append(checklist["score"] / 10 * 10)
    if daily_score is not None and daily_score.get("total"):
        parts.append(daily_score["score"] / daily_score["total"] * 10)
    if smart_money is not None and smart_money.get("possible"):
        parts.append(smart_money["score"] / smart_money["possible"] * 10)
    if near_high is not None and near_high.get("possible"):
        parts.append(near_high["score"] / near_high["possible"] * 10)

    if not parts:
        return None

    score = round(sum(parts) / len(parts), 1)

    if score >= 8:
        label = "STRONG"
    elif score >= 6:
        label = "GOOD"
    elif score >= 4:
        label = "MODERATE"
    else:
        label = "WEAK"

    return {"score": score, "label": label}


def passes_alert_gate(signal):
    """
    Alert Gate (SIMPLIFIED, per request, 2026-08-28 — "EMA CROSS WITH
    GOOD/STRONG TRADING SCORE") — a single condition. Sends the alert
    if, and only if, Trading Score is GOOD or STRONG:
      trading_score.score >= config.QUALITY_GATE_MIN_TRADING_SCORE
    (label bands: 8-10 STRONG, 6-7.9 GOOD, 4-5.9 MODERATE, <4 WEAK —
    see compute_trading_score). Trading Score already rolls up Daily
    Score, Buy/Sell Score, Smart Money, and Near-High into one number,
    so this single check effectively reflects all of them together —
    the previous 6-case OR-gate (Daily Score alone, Buy/Sell Score
    alone, Smart Money alone, a "combined" case, Bulk/Block deal,
    Volume Spike %) is REMOVED from the gate decision. Those fields
    are still computed and still shown on every alert message — only
    the gate's own pass/fail logic changed.

    Requires trading_score to already be attached to the signal.

    Returns (passed: bool, reasons: list[str]) — reasons has at most
    one entry, for logging / the "why this fired" line on the alert.
    """
    trading = signal.get("trading_score")
    trading_ok = trading is not None and trading["score"] >= config.QUALITY_GATE_MIN_TRADING_SCORE

    reasons = []
    if trading_ok:
        reasons.append(f"Trading Score {trading['label']} ({trading['score']}/10)")

    return trading_ok, reasons


def _resample_daily_to_monthly(history):
    """
    Converts a list of daily {"date","open","high","low","close",
    "volume"} dicts (oldest -> newest — main.fetch_daily_history's
    output) into monthly OHLCV bars: one row per calendar month, close
    = the LAST daily close seen in that month (the standard "monthly
    candle" convention). If `history` includes today (see
    fetch_daily_history's include_today), the current calendar
    month's row is a month-to-date bar, not a fully-closed one — the
    caller (get_monthly_rsi_info) treats it as "this month's RSI so
    far", same idea as watching a live, still-forming candle.
    """
    if not history:
        return pd.DataFrame()
    df = pd.DataFrame(history)
    df["date"] = pd.to_datetime(df["date"])
    df = df.set_index("date").sort_index()
    monthly = df.resample("MS").agg({
        "open": "first", "high": "max", "low": "min",
        "close": "last", "volume": "sum",
    })
    return monthly.dropna(subset=["close"])


def get_monthly_rsi_info(history):
    """
    Monthly RSI(config.MONTHLY_RSI_PERIOD) INFORMATIONAL snapshot
    (CHANGED, per request — "amar ager je alert ache tate monthly rsi
    ta add kore dao": folded into the EXISTING alert as one more info
    line, same as Near-High/Smart Money/EMA50-200-cross/etc., instead
    of being its own separate scan/summary message).

    `history` is main.fetch_daily_history's output — pass
    include_today=True so the current calendar month's bar reflects
    today's close too. Resamples to monthly candles
    (_resample_daily_to_monthly above) and computes RSI on monthly
    closes.

    Returns None if there isn't enough monthly history yet (needs
    config.MONTHLY_RSI_PERIOD + 2 monthly bars — one extra for the
    "previous month" comparison, one more so that comparison month
    itself isn't the very first, all-NaN RSI row). Otherwise:
      {"rsi": float, "prev_rsi": float, "month": "YYYY-MM",
       "above_70": bool, "fresh_cross": bool}
    "fresh_cross" is True only when THIS reading is a brand-new cross
    above config.MONTHLY_RSI_CROSS_LEVEL this calendar month (the
    previous fully-closed month's RSI was still below it) — not
    merely "has been over 70 for a while already".
    """
    monthly = _resample_daily_to_monthly(history)
    min_bars = config.MONTHLY_RSI_PERIOD + 2
    if len(monthly) < min_bars:
        return None

    monthly = add_rsi(monthly, config.MONTHLY_RSI_PERIOD)
    if pd.isna(monthly["rsi"].iloc[-1]) or pd.isna(monthly["rsi"].iloc[-2]):
        return None

    rsi_curr = round(float(monthly["rsi"].iloc[-1]), 1)
    rsi_prev = round(float(monthly["rsi"].iloc[-2]), 1)
    level = config.MONTHLY_RSI_CROSS_LEVEL

    return {
        "rsi": rsi_curr,
        "prev_rsi": rsi_prev,
        "month": monthly.index[-1].strftime("%Y-%m"),
        "above_70": rsi_curr >= level,
        "fresh_cross": rsi_prev < level <= rsi_curr,
    }


def compute_swing_confluence_score(df, row_idx=-1):
    """
    Reads ONE row (default: the latest) off an already
    indicator-decorated daily dataframe and turns it into a
    swing-entry confluence score (added, per request — "ekta perfect
    swing trade er alert... sob combine kore ekta confluence score").
    NOT financial advice — a mechanical, rules-based score.

    `df` must already have columns: close, high, low, volume, ema20,
    ema50, ema200, rsi, atr, vol_avg, swing_low_recent,
    swing_low_prior (see check_swing_entry_scan, which builds all of
    these once on the full history). All of them are CAUSAL —
    ewm()/rolling() only look backward — so reading row_idx=-2 here
    gives exactly what "yesterday's score" would have been; no need
    to recompute on a truncated frame.

    Five components, each normalized to /10, averaged with equal
    weight (same pattern as compute_trading_score elsewhere in this
    file):

      1. Trend alignment  — EMA20 > EMA50 > EMA200 AND close > EMA20.
         This one ALSO comes back as the separate "trend_ok" boolean
         below, because check_swing_entry_scan treats it as a hard,
         non-negotiable gate: no amount of momentum/volume/structure
         should make up for the higher-timeframe trend not being up.
      2. Momentum health  — RSI(14) 45-65 is "room to run"; the score
         falls off on both sides (overbought above ~65-75, weakening
         below ~45-35) — chasing an RSI already near 70+ is a
         classically bad fresh-entry moment, not a good one.
      3. Pullback quality — close's distance above EMA20, in ATRs.
         0-1 ATR above EMA20 is a shallow, buyable pullback; 1-3 ATRs
         is increasingly a chase; below EMA20 means the short-term
         trend may already be cracking.
      4. Volume confirmation — today's volume vs its 20-day average.
         A genuine entry/bounce day should show above-average
         participation, not a listless drift on thin volume.
      5. Structure — the most recent SWING_STRUCTURE_LOOKBACK-day
         swing low vs the one before it. Catches a stock that's
         technically "above its EMAs" but whose actual price
         structure underneath is already breaking down (lower lows).

    Returns None if any required value at row_idx is still NaN (not
    enough history for that indicator yet), or if atr/vol_avg is 0
    (division guard). Otherwise:
      {"score": float 0-10, "label": str, "trend_ok": bool,
       "components": {"trend","momentum","pullback","volume",
       "structure"}, "close", "atr", "swing_low_recent"}
    label bands: 8-10 STRONG, 6-7.9 GOOD, 4-5.9 MODERATE, <4 WEAK.
    """
    row = df.iloc[row_idx]
    needed = ["close", "ema20", "ema50", "ema200", "rsi", "atr",
              "vol_avg", "swing_low_recent", "swing_low_prior"]
    if any(pd.isna(row[c]) for c in needed):
        return None
    if row["atr"] <= 0 or row["vol_avg"] <= 0 or row["swing_low_prior"] <= 0:
        return None

    close, ema20, ema50, ema200 = row["close"], row["ema20"], row["ema50"], row["ema200"]
    rsi, atr, volume, vol_avg = row["rsi"], row["atr"], row["volume"], row["vol_avg"]
    swing_low_recent, swing_low_prior = row["swing_low_recent"], row["swing_low_prior"]

    # 1. Trend alignment — the one non-negotiable filter.
    trend_ok = (ema20 > ema50 > ema200) and (close > ema20)
    if ema20 > ema50 > ema200:
        score_trend = 10.0
    elif close > ema200 and ema20 > ema50:
        score_trend = 6.0
    elif close > ema200:
        score_trend = 3.0
    else:
        score_trend = 0.0

    # 2. Momentum health.
    if 45 <= rsi <= 65:
        score_momentum = 10.0
    elif 65 < rsi <= 75:
        score_momentum = max(0.0, 10 - (rsi - 65) * 0.8)
    elif rsi > 75:
        score_momentum = max(0.0, 2 - (rsi - 75) * 0.4)
    elif 35 <= rsi < 45:
        score_momentum = max(0.0, 10 - (45 - rsi) * 0.5)
    else:
        score_momentum = max(0.0, 5 - (35 - rsi) * 0.5)

    # 3. Pullback quality (distance above EMA20, in ATRs).
    dist_atr = (close - ema20) / atr
    if dist_atr < 0:
        score_pullback = max(0.0, 10 + dist_atr * 10)
    elif dist_atr <= 1:
        score_pullback = 10.0
    elif dist_atr <= 3:
        score_pullback = max(0.0, 10 - (dist_atr - 1) * 4)
    else:
        score_pullback = max(0.0, 2 - (dist_atr - 3) * 2)

    # 4. Volume confirmation (today's volume vs its 20-day average).
    vol_ratio = volume / vol_avg
    if vol_ratio >= 1.5:
        score_volume = 10.0
    elif vol_ratio >= 1.0:
        score_volume = 6 + (vol_ratio - 1.0) * 8
    elif vol_ratio >= 0.7:
        score_volume = 3 + (vol_ratio - 0.7) * 10
    else:
        score_volume = max(0.0, vol_ratio / 0.7 * 3)

    # 5. Structure (higher low vs the swing low before it).
    diff_pct = (swing_low_recent - swing_low_prior) / swing_low_prior * 100
    if diff_pct >= 0:
        score_structure = 10.0
    elif diff_pct >= -2:
        score_structure = 6.0
    elif diff_pct >= -5:
        score_structure = 3.0
    else:
        score_structure = 0.0

    components = {
        "trend": round(score_trend, 1),
        "momentum": round(score_momentum, 1),
        "pullback": round(score_pullback, 1),
        "volume": round(score_volume, 1),
        "structure": round(score_structure, 1),
    }
    score = round(sum(components.values()) / len(components), 1)

    if score >= 8:
        label = "STRONG"
    elif score >= 6:
        label = "GOOD"
    elif score >= 4:
        label = "MODERATE"
    else:
        label = "WEAK"

    return {
        "score": score, "label": label, "trend_ok": trend_ok,
        "components": components, "close": round(float(close), 2),
        "atr": round(float(atr), 2),
        "swing_low_recent": round(float(swing_low_recent), 2),
    }


def check_swing_entry_scan(history, symbol):
    """
    Swing-trade ENTRY screener (added, per request — "ekta perfect
    swing trade er alert ready kore dao dekhi... sob combine kore
    ekta confluence score"). NOT financial advice — a mechanical,
    rules-based technical screener; entry/stop/target below are just
    the arithmetic outputs of the rules, not a recommendation.

    `history` is main.fetch_daily_history's output (oldest -> newest
    daily candles; pass include_today=True so today counts). Builds
    ONE indicator-decorated dataframe (EMA20/50/200, RSI14, ATR14,
    20-day volume average, and the two swing-low columns
    compute_swing_confluence_score needs), then scores TODAY and
    YESTERDAY with that function.

    Fires only on a fresh cross INTO the qualifying zone THIS session
    — yesterday's score was below config.SWING_CONFLUENCE_MIN_SCORE,
    today's is at/above it (same "fresh cross, not still-qualifying"
    idea as get_monthly_rsi_info's "fresh_cross" flag, so a stock
    that stays strong for a week doesn't re-fire every single day) —
    AND hard-requires
    today's trend_ok == True (see compute_swing_confluence_score): a
    stock cannot qualify on momentum/volume/structure alone if the
    higher-timeframe EMA trend itself isn't up.

    Entry/stop/target are mechanical:
      entry  = today's close
      stop   = today's SWING_STRUCTURE_LOOKBACK-day low, minus
               config.SWING_STOP_ATR_BUFFER × ATR
      target = entry + config.SWING_TARGET_RRR × (entry - stop)

    Returns None if there isn't config.SWING_MIN_BARS worth of daily
    history yet, if today doesn't qualify, or if it already qualified
    yesterday (not a fresh cross), or if the mechanical stop ends up
    at/above entry (guard against a degenerate risk calc). Otherwise:
      {"symbol", "date", "close", "score", "label", "components",
       "entry", "stop", "target", "risk_per_share", "rr_ratio"}
    """
    if len(history) < config.SWING_MIN_BARS:
        return None

    df = pd.DataFrame(history)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)

    df = add_ema(df, config.SWING_EMA_FAST, "ema20")
    df = add_ema(df, config.SWING_EMA_SLOW, "ema50")
    df = add_ema(df, config.SWING_EMA_TREND, "ema200")
    df = add_rsi(df, config.SWING_RSI_PERIOD)
    df = add_atr(df, config.SWING_ATR_PERIOD)
    df = add_volume_avg(df, config.SWING_VOL_AVG_PERIOD)
    df["swing_low_recent"] = df["low"].rolling(config.SWING_STRUCTURE_LOOKBACK).min()
    df["swing_low_prior"] = df["swing_low_recent"].shift(config.SWING_STRUCTURE_LOOKBACK)

    today = compute_swing_confluence_score(df, -1)
    yesterday = compute_swing_confluence_score(df, -2)
    if today is None or yesterday is None:
        return None
    if not today["trend_ok"]:
        return None

    level = config.SWING_CONFLUENCE_MIN_SCORE
    if yesterday["score"] >= level or today["score"] < level:
        return None

    close = today["close"]
    atr = today["atr"]
    swing_low = today["swing_low_recent"]

    stop = round(swing_low - config.SWING_STOP_ATR_BUFFER * atr, 2)
    risk = round(close - stop, 2)
    if risk <= 0:
        return None
    target = round(close + config.SWING_TARGET_RRR * risk, 2)

    return {
        "symbol": symbol,
        "date": df["date"].iloc[-1].strftime("%Y-%m-%d"),
        "close": close,
        "score": today["score"],
        "label": today["label"],
        "components": today["components"],
        "entry": close,
        "stop": stop,
        "target": target,
        "risk_per_share": risk,
        "rr_ratio": config.SWING_TARGET_RRR,
    }


def check_daily_ema50_macd_scan(history, symbol):
    """
    Daily 50-EMA cross + MACD cross + RSI scan (added, per request
    2026-10-09). `history` is main.fetch_daily_history's output
    (oldest -> newest daily candles, include_today=True). Judges the
    LAST candle in `history` (the caller verifies it is today's).

    Fires (bullish only) when, on the last candle:
      1. close crossed ABOVE EMA(close, config.DAILY_EMA50_PERIOD):
         previous close <= previous EMA50 and last close > last EMA50
      2. MACD line crossed ABOVE the MACD signal line on that candle
         (or, if config.DAILY_EMA50_MACD_CROSS_LOOKBACK_DAYS = N > 0,
         within the last N candles before it as well)
      3. RSI(config.DAILY_EMA50_RSI_PERIOD) > config.DAILY_EMA50_RSI_MIN

    Returns None if there isn't enough history or any condition fails,
    else a dict with symbol/date/close/ema50/rsi/macd values plus two
    informational extras (day change %, volume vs 20-day average).
    """
    if len(history) < config.DAILY_EMA50_MIN_BARS:
        return None

    df = pd.DataFrame(history)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)

    df = add_ema(df, config.DAILY_EMA50_PERIOD, "ema50")
    df = add_macd(df)
    df = add_rsi(df, config.DAILY_EMA50_RSI_PERIOD)

    last = df.iloc[-1]
    prev = df.iloc[-2]
    if pd.isna(last["ema50"]) or pd.isna(prev["ema50"]) or pd.isna(last["rsi"]):
        return None

    # 1. fresh close-above-EMA50 cross on the last candle
    if not (prev["close"] <= prev["ema50"] and last["close"] > last["ema50"]):
        return None

    # 3. RSI strictly above the floor
    if not last["rsi"] > config.DAILY_EMA50_RSI_MIN:
        return None

    # 2. MACD line crossing above signal, on the last candle or (if
    # configured) within the last N candles
    lookback = max(0, int(config.DAILY_EMA50_MACD_CROSS_LOOKBACK_DAYS))
    macd_cross_days_ago = None
    for k in range(lookback + 1):
        i = len(df) - 1 - k
        if i < 1:
            break
        m_now, s_now = df["macd_line"].iloc[i], df["macd_signal"].iloc[i]
        m_prev, s_prev = df["macd_line"].iloc[i - 1], df["macd_signal"].iloc[i - 1]
        if m_prev <= s_prev and m_now > s_now:
            macd_cross_days_ago = k
            break
    if macd_cross_days_ago is None:
        return None

    day_change_pct = (last["close"] / prev["close"] - 1) * 100 if prev["close"] else None
    vol_avg = df["volume"].iloc[-21:-1].mean() if len(df) > 21 else None
    vol_ratio = (last["volume"] / vol_avg) if vol_avg and vol_avg > 0 else None

    return {
        "symbol": symbol,
        "date": df["date"].iloc[-1].strftime("%Y-%m-%d"),
        "close": round(float(last["close"]), 2),
        "ema50": round(float(last["ema50"]), 2),
        "rsi": round(float(last["rsi"]), 1),
        "macd_line": round(float(last["macd_line"]), 3),
        "macd_signal": round(float(last["macd_signal"]), 3),
        "macd_cross_days_ago": macd_cross_days_ago,
        "day_change_pct": round(float(day_change_pct), 2) if day_change_pct is not None else None,
        "volume_vs_20d_avg": round(float(vol_ratio), 2) if vol_ratio is not None else None,
    }


def check_monthly_macd_rsi_scan(history, symbol):
    """
    1-MONTH timeframe alert (ADDED 2026-10-19, per request — "15 minite
    eo cross e asbe abar 1 month eo asbe"). Same trigger as the 15-min
    alert, on MONTHLY candles: the monthly MACD line crosses its signal
    line on the latest monthly bar AND monthly RSI(14) agrees
    (> config.ALERT_RSI_BULLISH_MIN for BULLISH, < ALERT_RSI_BEARISH_MAX
    for BEARISH).

    `history` = main.fetch_daily_history output with include_today=True.
    The latest monthly bar is the CURRENT month so far (a live,
    still-forming candle — the cross can still flip back before month
    end; the alert says so). With config.MONTHLY_ALERT_COMPLETED_ONLY =
    True that in-progress bar is dropped and only a cross on the last
    fully-closed month fires (i.e. alerts arrive in the first days of the
    next month).

    Returns None (no signal / not enough monthly bars) or a dict.
    """
    monthly = _resample_daily_to_monthly(history)
    if monthly.empty:
        return None

    last_day = pd.to_datetime(history[-1]["date"])
    in_progress = (monthly.index[-1].year, monthly.index[-1].month) == (last_day.year, last_day.month)
    if getattr(config, "MONTHLY_ALERT_COMPLETED_ONLY", False) and in_progress and len(monthly) > 1:
        monthly = monthly.iloc[:-1]
        in_progress = False

    if len(monthly) < config.MONTHLY_ALERT_MIN_BARS:
        return None

    monthly = add_macd(monthly, config.MACD_FAST, config.MACD_SLOW, config.MACD_SIGNAL)
    monthly = add_rsi(monthly, config.RSI_PERIOD)
    last, prev = monthly.iloc[-1], monthly.iloc[-2]
    if pd.isna(last["rsi"]) or pd.isna(last["macd_signal"]) or pd.isna(prev["macd_signal"]):
        return None

    prev_diff = prev["macd_line"] - prev["macd_signal"]
    curr_diff = last["macd_line"] - last["macd_signal"]
    rsi = float(last["rsi"])
    if prev_diff <= 0 < curr_diff and rsi > config.ALERT_RSI_BULLISH_MIN:
        direction = "BULLISH"
    elif prev_diff >= 0 > curr_diff and rsi < config.ALERT_RSI_BEARISH_MAX:
        direction = "BEARISH"
    else:
        return None
    close = float(last["close"])
    prev_close = float(prev["close"])
    return {
        "symbol": symbol,
        "direction": direction,
        "month": monthly.index[-1].strftime("%b %Y"),
        "in_progress": bool(in_progress),
        "close": round(close, 2),
        "month_change_pct": round((close / prev_close - 1) * 100, 2) if prev_close else None,
        "rsi": round(rsi, 1),
        "macd_line": round(float(last["macd_line"]), 2),
        "macd_signal": round(float(last["macd_signal"]), 2),
    }


def check_daily_macd_rsi_scan(history, symbol, delivery_pct=None, delivery_avg_1m=None):
    """
    DAILY MACD+RSI alert (ADDED 2026-10-22). Same idea as the 15-min alert on
    DAILY candles. `history` = main.fetch_daily_history output.

    Trigger: MACD(12/26/9) line crosses its signal line on the last daily candle
    or up to DAILY_ALERT_CROSS_LOOKBACK-1 candles earlier (MACD still on that
    side now). MUST: MACD on the right side of zero (+ RSI and volume when
    DAILY_ALERT_MANDATORY_RSI_VOLUME). Then more checks, 1 point each (BULLISH
    shown; BEARISH is the mirror): RSI >= 55, close above daily EMA50 / EMA200,
    EMA 9/20 bullish, close above the prior 21-day high, volume > 20-day
    average, previous-day delivery % > 1M avg. Checks with no data are skipped
    and the number needed is scaled down in proportion.
    Returns None (no cross / not enough data) or a dict, incl. meets_min.
    """
    if len(history) < config.DAILY_ALERT_MIN_BARS:
        return None
    df = pd.DataFrame(history)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    df = add_macd(df, config.MACD_FAST, config.MACD_SLOW, config.MACD_SIGNAL)
    df = add_rsi(df, config.RSI_PERIOD)
    for p in (9, 20, 50, 200):
        df = add_ema(df, p, f"ema{p}")

    last, prev = df.iloc[-1], df.iloc[-2]
    if pd.isna(last["rsi"]) or pd.isna(last["macd_signal"]) or pd.isna(prev["macd_signal"]):
        return None

    # Cross may be on the last candle or up to DAILY_ALERT_CROSS_LOOKBACK-1 candles
    # earlier (2026-10-23 — "last day r alert elo na"), but MACD must still be on
    # that side now. The cross candle's date is the dedupe date.
    diff = (df["macd_line"] - df["macd_signal"])
    look = max(1, int(getattr(config, "DAILY_ALERT_CROSS_LOOKBACK", 1)))
    direction, cross_idx = None, None
    for k in range(0, look):
        i = len(df) - 1 - k
        if i < 1 or pd.isna(diff.iloc[i]) or pd.isna(diff.iloc[i - 1]):
            break
        if diff.iloc[i - 1] <= 0 < diff.iloc[i] and diff.iloc[-1] > 0:
            direction, cross_idx = "BULLISH", i
            break
        if diff.iloc[i - 1] >= 0 > diff.iloc[i] and diff.iloc[-1] < 0:
            direction, cross_idx = "BEARISH", i
            break
    if direction is None:
        return None
    bull = direction == "BULLISH"
    close = float(last["close"])

    checks, mandatory_failed = [], []

    def add(name, ok, must=False):
        checks.append((name, bool(ok)))
        if must and not ok:
            mandatory_failed.append(name)

    ml = float(last["macd_line"])
    add("MACD " + ("above" if bull else "below") + " zero line", ml > 0 if bull else ml < 0, must=True)
    rsi = float(last["rsi"])
    lim = config.ALERT_STRONG_RSI_BULLISH if bull else config.ALERT_STRONG_RSI_BEARISH
    must_rv = getattr(config, "DAILY_ALERT_MANDATORY_RSI_VOLUME", False)
    add(f"RSI {'≥' if bull else '≤'} {lim}", rsi >= lim if bull else rsi <= lim, must=must_rv)
    add("Daily EMA50 " + ("above" if bull else "below"), (close > float(last["ema50"])) == bull)
    if len(df) >= 200:
        add("Daily EMA200 " + ("above" if bull else "below"), (close > float(last["ema200"])) == bull)
    add("EMA 9/20 " + ("bullish" if bull else "bearish"), (float(last["ema9"]) > float(last["ema20"])) == bull)
    if len(df) >= 22:
        window = df.iloc[-21:-1]   # prior 20 trading days
        if bull:
            add("Above 20-day high", close > float(window["high"].max()))
        else:
            add("Below 20-day low", close < float(window["low"].min()))
    vol_pct = None
    if len(df) >= 22 and float(last["volume"]) > 0:
        avg_v = float(df["volume"].iloc[-21:-1].mean())
        if avg_v > 0:
            vol_pct = (float(last["volume"]) / avg_v - 1) * 100
            add("Volume > 20-day avg", float(last["volume"]) > avg_v, must=must_rv)
    deliv_pct = None
    if delivery_pct is not None and delivery_avg_1m:
        deliv_pct = (delivery_pct / delivery_avg_1m - 1) * 100
        add("Delivery > 20D avg", delivery_pct > delivery_avg_1m)

    total = len(checks)
    passed = sum(1 for _, ok in checks if ok)
    full = max(1, int(config.DAILY_ALERT_FULL_CHECK_COUNT))
    need = math.ceil(config.DAILY_ALERT_MIN_CHECKS_PASSED * total / full - 1e-9) if total else 0
    prev_close = float(prev["close"])
    return {
        "symbol": symbol,
        "direction": direction,
        "date": df["date"].iloc[cross_idx].strftime("%Y-%m-%d"),
        "cross_days_ago": len(df) - 1 - cross_idx,
        "candle_date": df["date"].iloc[-1].strftime("%Y-%m-%d"),
        "close": round(close, 2),
        "day_change_pct": round((close / prev_close - 1) * 100, 2) if prev_close else None,
        "rsi": round(rsi, 1),
        "macd_line": round(ml, 2),
        "macd_signal": round(float(last["macd_signal"]), 2),
        "checks": checks,
        "passed": passed, "total": total, "need": need,
        "mandatory_failed": mandatory_failed,
        "meets_min": passed >= need and not mandatory_failed,
        "volume_vs_avg_pct": round(vol_pct, 1) if vol_pct is not None else None,
        "delivery_vs_avg_pct": round(deliv_pct, 1) if deliv_pct is not None else None,
    }


def get_daily_support_info(history, direction):
    """
    DAILY (MACD + RSI + VOLUME) support for an intraday alert (ADDED 2026-10-22).
    `history` = main.fetch_daily_history output (COMPLETED daily candles only).
    Judged on the last completed daily candle:
      macd_ok   — daily MACD line on the alert's side of its signal line
                  (above for BULLISH, below for BEARISH); macd_days_ago = how many
                  daily candles ago it crossed that way (None = no cross in the last 10)
      rsi_ok    — daily RSI >= ALERT_STRONG_RSI_BULLISH (BULLISH) / <= _BEARISH (BEARISH)
      vol_ok    — that day's volume above the average of the 20 days before it
    Returns None when there isn't enough history.
    """
    if not history or len(history) < 60:
        return None
    df = pd.DataFrame(history)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)
    df = add_macd(df, config.MACD_FAST, config.MACD_SLOW, config.MACD_SIGNAL)
    df = add_rsi(df, config.RSI_PERIOD)
    last = df.iloc[-1]
    if pd.isna(last["rsi"]) or pd.isna(last["macd_signal"]):
        return None
    bull = direction == "BULLISH"
    diff = df["macd_line"] - df["macd_signal"]
    macd_ok = bool(diff.iloc[-1] > 0) if bull else bool(diff.iloc[-1] < 0)
    days_ago = None
    if macd_ok:
        for k in range(0, 10):
            i = len(df) - 1 - k
            if i < 1:
                break
            if (bull and diff.iloc[i - 1] <= 0 < diff.iloc[i]) or ((not bull) and diff.iloc[i - 1] >= 0 > diff.iloc[i]):
                days_ago = k
                break
    rsi = float(last["rsi"])
    lim = config.ALERT_STRONG_RSI_BULLISH if bull else config.ALERT_STRONG_RSI_BEARISH
    rsi_ok = rsi >= lim if bull else rsi <= lim
    vol_pct, vol_ok = None, None
    if len(df) >= 22:
        avg_v = float(df["volume"].iloc[-21:-1].mean())
        if avg_v > 0 and float(last["volume"]) > 0:
            vol_pct = (float(last["volume"]) / avg_v - 1) * 100
            vol_ok = vol_pct > 0
    return {
        "date": df["date"].iloc[-1].strftime("%Y-%m-%d"),
        "macd_ok": macd_ok, "macd_days_ago": days_ago,
        "rsi": round(rsi, 1), "rsi_ok": bool(rsi_ok),
        "vol_pct": round(vol_pct, 1) if vol_pct is not None else None,
        "vol_ok": vol_ok,
    }
